import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import type { Peer, ChatMessage } from "../models";
import type { RootState } from "./store";

export type PeersState = Peer[];

const initialState: PeersState = [];

const peersSlice = createSlice({
  name: "peers",
  initialState,
  reducers: {
    addPeer: (state, action: PayloadAction<Peer>) => {
      state.push(action.payload);
    },

    setPeerOnline: (state, action: PayloadAction<string>) => {
      const peer = state.find((p) => p.id === action.payload);
      if (peer) peer.online = true;
    },

    removePeer: (state, action: PayloadAction<string>) => {
      return state.filter((p) => p.id !== action.payload);
    },

    messageAddedToPeer: (state, action: PayloadAction<{ peerId: string; message: ChatMessage }>) => {
      const peer = state.find((p) => p.id === action.payload.peerId);
      peer?.messages.push(action.payload.message);
    },
  },
});

export const { addPeer, setPeerOnline, removePeer, messageAddedToPeer } = peersSlice.actions;
export default peersSlice.reducer;

export const selectPeers = (state: RootState) => state.peers;
export const selectPeerById = (state: RootState, peerId: string) =>
  state.peers.find((p : Peer) => p.id === peerId);
