import { configureStore } from "@reduxjs/toolkit";
import peersReducer from "./peersSlice";
import groupsReducer from "./groupsSlice";
import uiReducer from "./uiSlice";
import connectionReducer from "./connectionSlice";
import { socketListenerMiddleware } from "./socket-middleware";

/* eslint-disable no-underscore-dangle */
export const store = configureStore({
  reducer: {
    peers: peersReducer,
    groups: groupsReducer,
    ui: uiReducer,
    connection: connectionReducer,
  },
  devTools: (window as any).__REDUX_DEVTOOLS_EXTENSION__ && (window as any).__REDUX_DEVTOOLS_EXTENSION__(),
  middleware: (getDefaultMiddleware) => getDefaultMiddleware().prepend(socketListenerMiddleware.middleware),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
