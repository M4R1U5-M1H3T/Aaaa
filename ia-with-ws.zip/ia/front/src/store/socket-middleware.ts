import { createListenerMiddleware, createAction } from "@reduxjs/toolkit";
import type { AppDispatch } from "./store";
import { addPeer, removePeer, messageAddedToPeer } from "./peersSlice";
import { setSocketConnected, setListening } from "./connectionSlice";

// Where the local backend's front-facing WebSocket bridge is listening.
// Override with VITE_BACKEND_WS_URL if the backend was started on a non-default port.
const WS_URL = import.meta.env.VITE_BACKEND_WS_URL ?? "ws://localhost:8081";

// Intents dispatched by the UI - handled below by talking to the backend.
export const socketInitRequested = createAction("socket/initRequested");
export const peerConnectRequested = createAction<{ host: string; port: string }>("socket/peerConnectRequested");
export const peerMessageSent = createAction<{ peerId: string; text: string }>("socket/peerMessageSent");
export const peerDisconnectRequested = createAction<string>("socket/peerDisconnectRequested");

export const socketListenerMiddleware = createListenerMiddleware();

let socket: WebSocket | null = null;

function ensureSocket(dispatch: AppDispatch): WebSocket {
  if (socket && socket.readyState !== WebSocket.CLOSED && socket.readyState !== WebSocket.CLOSING) {
    return socket;
  }

  const ws = new WebSocket(WS_URL);
  socket = ws;

  ws.onopen = () => dispatch(setSocketConnected(true));

  ws.onclose = () => {
    dispatch(setSocketConnected(false));
    if (socket === ws) socket = null;
  };

  ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    switch (data.type) {
      case "LISTENING":
        dispatch(setListening({ port: data.port, name: data.name }));
        break;
      case "PEER_CONNECTED":
        dispatch(addPeer({ id: data.peerId, name: data.name ?? data.peerId, online: true, messages: [] }));
        break;
      case "MESSAGE":
        dispatch(
          messageAddedToPeer({
            peerId: data.peerId,
            message: { author: data.from, text: data.text, fromMe: false },
          })
        );
        break;
      case "PEER_DISCONNECTED":
        dispatch(removePeer(data.peerId));
        break;
      case "ERROR":
        console.error("Backend error:", data.error);
        break;
      default:
        break;
    }
  };

  return ws;
}

function sendWhenOpen(ws: WebSocket, payload: unknown) {
  const send = () => ws.send(JSON.stringify(payload));
  if (ws.readyState === WebSocket.OPEN) {
    send();
  } else {
    ws.addEventListener("open", send, { once: true });
  }
}

socketListenerMiddleware.startListening({
  actionCreator: socketInitRequested,
  effect: (_action, listenerApi) => {
    ensureSocket(listenerApi.dispatch as AppDispatch);
  },
});

socketListenerMiddleware.startListening({
  actionCreator: peerConnectRequested,
  effect: (action, listenerApi) => {
    const ws = ensureSocket(listenerApi.dispatch as AppDispatch);
    sendWhenOpen(ws, { type: "CONNECT", host: action.payload.host, port: Number(action.payload.port) });
  },
});

socketListenerMiddleware.startListening({
  actionCreator: peerMessageSent,
  effect: (action, listenerApi) => {
    const ws = ensureSocket(listenerApi.dispatch as AppDispatch);
    sendWhenOpen(ws, { type: "SEND", peerId: action.payload.peerId, text: action.payload.text });
  },
});

socketListenerMiddleware.startListening({
  actionCreator: peerDisconnectRequested,
  effect: (action, listenerApi) => {
    const ws = ensureSocket(listenerApi.dispatch as AppDispatch);
    sendWhenOpen(ws, { type: "DISCONNECT", peerId: action.payload });
  },
});
