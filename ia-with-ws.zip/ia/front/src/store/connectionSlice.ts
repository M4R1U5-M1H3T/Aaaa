import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import type { RootState } from "./store";

export interface ConnectionState {
  socketConnected: boolean;
  listeningPort: number | null;
  localName: string | null;
}

const initialState: ConnectionState = {
  socketConnected: false,
  listeningPort: null,
  localName: null,
};

const connectionSlice = createSlice({
  name: "connection",
  initialState,
  reducers: {
    setSocketConnected: (state, action: PayloadAction<boolean>) => {
      state.socketConnected = action.payload;
      if (!action.payload) state.listeningPort = null;
    },

    setListening: (state, action: PayloadAction<{ port: number; name: string }>) => {
      state.listeningPort = action.payload.port;
      state.localName = action.payload.name;
    },
  },
});

export const { setSocketConnected, setListening } = connectionSlice.actions;
export default connectionSlice.reducer;

export const selectSocketConnected = (state: RootState) => state.connection.socketConnected;
export const selectListeningPort = (state: RootState) => state.connection.listeningPort;
export const selectLocalName = (state: RootState) => state.connection.localName;
