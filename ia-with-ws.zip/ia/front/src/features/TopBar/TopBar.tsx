import './TopBar.css';
import { useAppSelector, selectSocketConnected, selectListeningPort, selectLocalName } from "../../store";

export const TopBar = () => {
  const connected = useAppSelector(selectSocketConnected);
  const port = useAppSelector(selectListeningPort);
  const name = useAppSelector(selectLocalName);

  return (
    <header className="topBar">
      <div className="userInfo">
        <span className={`statusDot ${connected ? "online" : ""}`}></span>
        <span className="userName">{name ?? "You"}</span>
        <span className="userMeta">
          {connected && port !== null ? `listening on port ${port}` : "connecting to backend..."}
        </span>
      </div>
    </header>
  );
};
