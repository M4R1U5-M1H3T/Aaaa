import { useEffect } from "react";
import { TopBar, ConnectSection, Sidebar, ChatArea } from "../../features";
import { useAppDispatch, socketInitRequested } from "../../store";
import "./ChatApp.css";

export const ChatApp = () => {
  const dispatch = useAppDispatch();

  useEffect(() => {
    dispatch(socketInitRequested());
  }, [dispatch]);

  return (
    <>
    <div className="appContainer">
      <TopBar />
      <ConnectSection />

      <div className="mainArea">
        <Sidebar />
        <ChatArea />
      </div>
    </div>
    </>
  );
};
