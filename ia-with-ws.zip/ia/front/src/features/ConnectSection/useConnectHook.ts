import { useState } from 'react';
import { useAppDispatch, peerConnectRequested } from "../../store";

export const useConnectHook = () => {
  const dispatch = useAppDispatch();

  const [host, setHost] = useState("127.0.0.1");
  const [port, setPort] = useState("");

  const handleConnect = () => {
    if (host.trim() === "" || port.trim() === "") return;
    dispatch(peerConnectRequested({ host: host.trim(), port: port.trim() }));
  };

  return { host, setHost, port, setPort, handleConnect };
};
