import "./ChatHeader.css";
import type { ChatHeaderProps } from "../../models";

export const ChatHeader = ({ title, showInviteButton, onToggleInvite, showDisconnectButton, onDisconnect }: ChatHeaderProps) => {
  return (
    <div className="chatHeader">
      <div className="chatTitle">{title}</div>
      <div className="chatButtons">
        {showInviteButton && (
          <button className="button" onClick={onToggleInvite}>
            invite
          </button>
        )}
        {showDisconnectButton && (
          <button className="button" onClick={onDisconnect}>
            disconnect
          </button>
        )}
      </div>
    </div>
  );
};
