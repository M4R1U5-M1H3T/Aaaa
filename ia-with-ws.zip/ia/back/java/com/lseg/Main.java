package com.lseg;

import com.lseg.front.FrontServer;

import java.io.IO;
import java.io.IOException;

public class Main {
    private static final int DEFAULT_FRONT_PORT = 8081;

    static void main() throws IOException {
        IO.println("What is your name?");
        String name = IO.readln();

        IO.println("Port for the frontend to connect to? (default " + DEFAULT_FRONT_PORT + ")");
        String portText = IO.readln();
        int frontPort = portText == null || portText.isBlank()
                ? DEFAULT_FRONT_PORT
                : Integer.parseInt(portText.trim());

        FrontServer frontServer = new FrontServer(frontPort, name);
        frontServer.start();
        Runtime.getRuntime().addShutdownHook(new Thread(frontServer::shutdown));

        IO.println("Waiting for the frontend on ws://localhost:" + frontPort + " ...");
    }
}
