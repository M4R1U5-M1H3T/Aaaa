package com.lseg.front;

public enum FrontMessageType {
    // front -> back
    CONNECT,
    SEND,
    DISCONNECT,

    // back -> front
    LISTENING,
    PEER_CONNECTED,
    MESSAGE,
    PEER_DISCONNECTED,
    ERROR
}
