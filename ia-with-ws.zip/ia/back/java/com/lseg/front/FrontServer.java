package com.lseg.front;

import com.lseg.network.Connection;
import com.lseg.network.ConnectionListener;
import com.lseg.network.ConnectionManager;
import com.lseg.protocol.Message;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

import java.io.IOException;
import java.net.InetSocketAddress;

/**
 * Bridges the React frontend to the existing peer-to-peer {@link ConnectionManager}.
 * This is the "front &lt;-&gt; back" WebSocket: the frontend connects here and drives
 * listen/connect/sendMessage/disconnect the same way the old CLI did, and this class
 * pushes peer events (connected/message/disconnected) back to the frontend as JSON.
 * <p>
 * Group chat stays out of scope here - it's left mocked on the frontend.
 */
public class FrontServer extends WebSocketServer implements ConnectionListener {
    private static final Logger log = LogManager.getLogger(FrontServer.class);

    private final String localName;
    private final ConnectionManager manager;
    private volatile WebSocket front;

    public FrontServer(int port, String localName) {
        super(new InetSocketAddress(port));
        this.localName = localName;
        this.manager = new ConnectionManager(localName, this);
        setReuseAddr(true);
    }

    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {
        front = conn;
        log.info("Frontend connected from {}", conn.getRemoteSocketAddress());
        ensureListening();
    }

    @Override
    public void onMessage(WebSocket conn, String raw) {
        FrontMessage message;
        try {
            message = FrontMessage.fromJson(raw);
        } catch (Exception e) {
            sendToFront(FrontMessage.error("Bad request: " + e.getMessage()));
            return;
        }
        if (message.getType() == null) {
            sendToFront(FrontMessage.error("Missing message type"));
            return;
        }
        switch (message.getType()) {
            case CONNECT -> doConnect(message);
            case SEND -> doSend(message);
            case DISCONNECT -> doDisconnect(message);
            default -> sendToFront(FrontMessage.error("Unsupported command: " + message.getType()));
        }
    }

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        log.info("Frontend disconnected: {}", reason);
        if (conn == front) {
            front = null;
        }
    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        log.warn("Front bridge connection error", ex);
    }

    @Override
    public void onStart() {
        log.info("Front bridge ready for the UI on port {}", getPort());
    }

    private void ensureListening() {
        try {
            if (manager.getListeningPort() == null) {
                manager.startListening();
            }
            sendToFront(FrontMessage.listening(manager.getListeningPort(), localName));
        } catch (IOException e) {
            log.warn("Could not start listening for peers", e);
            sendToFront(FrontMessage.error("Could not start listening: " + e.getMessage()));
        }
    }

    private void doConnect(FrontMessage message) {
        if (message.getHost() == null || message.getPort() == null) {
            sendToFront(FrontMessage.error("Usage: connect requires host and port"));
            return;
        }
        try {
            manager.connectTo(message.getHost(), message.getPort());
            // success is reported asynchronously through onConnected() below
        } catch (IOException e) {
            sendToFront(FrontMessage.error("Could not connect: " + e.getMessage()));
        }
    }

    private void doSend(FrontMessage message) {
        Connection connection = manager.get(message.getPeerId());
        if (connection == null) {
            sendToFront(FrontMessage.error("No such peer: " + message.getPeerId()));
            return;
        }
        connection.send(Message.chat(localName, message.getText()));
    }

    private void doDisconnect(FrontMessage message) {
        manager.close(message.getPeerId());
    }

    // ConnectionListener: peer <-> peer events, forwarded to the frontend

    @Override
    public void onConnected(Connection connection) {
        sendToFront(FrontMessage.peerConnected(connection.getId(), connection.getRemoteName()));
    }

    @Override
    public void onMessage(Connection connection, Message message) {
        String from = connection.getRemoteName() != null ? connection.getRemoteName() : connection.getId();
        sendToFront(FrontMessage.message(connection.getId(), from, message.getContent()));
    }

    @Override
    public void onDisconnected(Connection connection, String reason) {
        sendToFront(FrontMessage.peerDisconnected(connection.getId(), reason));
    }

    private void sendToFront(FrontMessage message) {
        WebSocket ws = front;
        if (ws == null || !ws.isOpen()) {
            return;
        }
        try {
            ws.send(message.toJson());
        } catch (Exception e) {
            log.debug("Could not send to frontend: {}", e.getMessage());
        }
    }

    public void shutdown() {
        manager.close();
        try {
            stop(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
