package com.lseg.front;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lseg.exceptions.JsonDeserializationException;
import com.lseg.exceptions.JsonSerializationException;

/**
 * Simple JSON messages exchanged between the frontend and its local backend
 * over the front&lt;-&gt;back WebSocket. Kept separate from {@link com.lseg.protocol.Message},
 * which is the back&lt;-&gt;back peer protocol (hello/ack/msg/bye).
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class FrontMessage {
    private final FrontMessageType type;
    private final String peerId;
    private final String host;
    private final Integer port;
    private final String name;
    private final String from;
    private final String text;
    private final String reason;
    private final String error;

    private static final ObjectMapper objectMapper = new ObjectMapper();

    @JsonCreator
    public FrontMessage(
            @JsonProperty("type") FrontMessageType type,
            @JsonProperty("peerId") String peerId,
            @JsonProperty("host") String host,
            @JsonProperty("port") Integer port,
            @JsonProperty("name") String name,
            @JsonProperty("from") String from,
            @JsonProperty("text") String text,
            @JsonProperty("reason") String reason,
            @JsonProperty("error") String error
    ) {
        this.type = type;
        this.peerId = peerId;
        this.host = host;
        this.port = port;
        this.name = name;
        this.from = from;
        this.text = text;
        this.reason = reason;
        this.error = error;
    }

    public static FrontMessage listening(int port, String localName) {
        return new FrontMessage(FrontMessageType.LISTENING, null, null, port, localName, null, null, null, null);
    }

    public static FrontMessage peerConnected(String peerId, String name) {
        return new FrontMessage(FrontMessageType.PEER_CONNECTED, peerId, null, null, name, null, null, null, null);
    }

    public static FrontMessage message(String peerId, String from, String text) {
        return new FrontMessage(FrontMessageType.MESSAGE, peerId, null, null, null, from, text, null, null);
    }

    public static FrontMessage peerDisconnected(String peerId, String reason) {
        return new FrontMessage(FrontMessageType.PEER_DISCONNECTED, peerId, null, null, null, null, null, reason, null);
    }

    public static FrontMessage error(String error) {
        return new FrontMessage(FrontMessageType.ERROR, null, null, null, null, null, null, null, error);
    }

    public FrontMessageType getType() {
        return this.type;
    }

    public String getPeerId() {
        return this.peerId;
    }

    public String getHost() {
        return this.host;
    }

    public Integer getPort() {
        return this.port;
    }

    public String getName() {
        return this.name;
    }

    public String getFrom() {
        return this.from;
    }

    public String getText() {
        return this.text;
    }

    public String getReason() {
        return this.reason;
    }

    public String getError() {
        return this.error;
    }

    public String toJson() {
        try {
            return objectMapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            throw new JsonSerializationException("Failed to serialize front message of type " + this.type, e);
        }
    }

    public static FrontMessage fromJson(String line) {
        try {
            return objectMapper.readValue(line, FrontMessage.class);
        } catch (JsonProcessingException e) {
            throw new JsonDeserializationException("Invalid front message: " + line, e);
        }
    }
}
