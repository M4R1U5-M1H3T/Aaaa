import { ChatApp } from "./features/ChatApp";

export default function App() {
  return <ChatApp />;
}
