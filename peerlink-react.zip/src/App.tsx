import { useAppState } from "./useAppState";
import { TopBar } from "./components/TopBar/TopBar";
import { ConnectForm } from "./components/ConnectForm/ConnectForm";
import { Sidebar } from "./components/Sidebar/Sidebar";
import { ChatArea } from "./components/ChatArea/ChatArea";

// The only component that knows the state lives in useAppState. Every
// component below it only ever sees plain props and callbacks - none of
// them import the hook themselves - so the state could later be swapped
// for a real backend without touching a single component.
export default function App() {
  const state = useAppState();

  const activePeer =
    state.activeThread?.type === "peer"
      ? state.peers.find((p) => p.id === state.activeThread!.id)
      : undefined;
  const activeGroup =
    state.activeThread?.type === "group"
      ? state.groups.find((g) => g.id === state.activeThread!.id)
      : undefined;

  const title = activePeer
    ? activePeer.name
    : activeGroup
      ? `# ${activeGroup.name} (${activeGroup.members.length + 1} members)`
      : "select a peer or group";

  const messages = activePeer?.messages ?? activeGroup?.messages ?? [];

  return (
    <div className="appContainer">
      <TopBar />
      <ConnectForm onConnect={state.connectToPeer} />

      <div className="mainArea">
        <Sidebar
          peers={state.peers}
          groups={state.groups}
          activePeerId={activePeer?.id ?? null}
          activeGroupId={activeGroup?.id ?? null}
          onSelectPeer={(id) => state.openChat("peer", id)}
          onSelectGroup={(id) => state.openChat("group", id)}
          onCreateGroup={state.createGroup}
        />

        <ChatArea
          title={title}
          messages={messages}
          hasOpenChat={state.activeThread !== null}
          isGroup={activeGroup !== undefined}
          groupMembers={activeGroup?.members ?? []}
          peopleToInvite={state.peopleToInvite}
          showInviteBox={activeGroup !== undefined && state.inviteBoxOpenFor === activeGroup.id}
          onToggleInvite={() => activeGroup && state.toggleInvite(activeGroup.id)}
          onInvite={(names) => activeGroup && state.invite(activeGroup.id, names)}
          onSendMessage={state.sendMessage}
        />
      </div>
    </div>
  );
}
