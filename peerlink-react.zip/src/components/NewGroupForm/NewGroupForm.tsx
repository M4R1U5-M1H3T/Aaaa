import { useState } from "react";

interface NewGroupFormProps {
  onCreate: (name: string) => void;
}

// The small "name + create" form for making a new group. Same pattern as
// ConnectForm: owns its own input, only calls outward once, on submit.
export function NewGroupForm({ onCreate }: NewGroupFormProps) {
  const [name, setName] = useState("");

  function handleCreate() {
    onCreate(name);
    setName("");
  }

  return (
    <div className="newGroupForm">
      <input
        className="textInput"
        placeholder="group name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button className="button mainButton smallButton" onClick={handleCreate}>
        create
      </button>
    </div>
  );
}
