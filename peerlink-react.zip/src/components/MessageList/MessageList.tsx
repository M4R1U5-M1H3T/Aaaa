import type { ChatMessage } from "../../models/ChatMessage";
import "./MessageList.css";

interface MessageListProps {
  messages: ChatMessage[];
  hasOpenChat: boolean;
}

// Just draws whatever messages it's given, plus the two empty states. It
// has no idea whether it's looking at a peer or a group thread - that
// distinction is resolved before the messages ever reach this component.
export function MessageList({ messages, hasOpenChat }: MessageListProps) {
  if (!hasOpenChat) {
    return <div className="emptyText">pick a peer or a group to start chatting</div>;
  }
  if (messages.length === 0) {
    return <div className="emptyText">no messages yet</div>;
  }
  return (
    <>
      {messages.map((message, index) => (
        <div key={index} className={`message ${message.fromMe ? "myMessage" : ""}`}>
          <div className="messageAuthor">{message.author}</div>
          <div>{message.text}</div>
        </div>
      ))}
    </>
  );
}
