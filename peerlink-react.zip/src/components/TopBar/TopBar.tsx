// Shows who you are and what port you're "listening" on. Purely
// presentational: no state, no callbacks - it only ever displays two
// pieces of text, so it needs nothing else.
export function TopBar() {
  return (
    <header className="topBar">
      <div className="userInfo">
        <span className="statusDot online"></span>
        <span className="userName">You</span>
        <span className="userMeta">listening on port 64894</span>
      </div>
    </header>
  );
}
