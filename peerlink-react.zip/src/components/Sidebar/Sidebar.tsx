import type { Peer } from "../../models/Peer";
import type { Group } from "../../models/Group";
import { PeerList } from "../PeerList/PeerList";
import { GroupList } from "../GroupList/GroupList";
import { NewGroupForm } from "../NewGroupForm/NewGroupForm";

interface SidebarProps {
  peers: Peer[];
  groups: Group[];
  activePeerId: string | null;
  activeGroupId: string | null;
  onSelectPeer: (id: string) => void;
  onSelectGroup: (id: string) => void;
  onCreateGroup: (name: string) => void;
}

// Lays out the left column. It doesn't render any list items itself - that
// job belongs to PeerList/GroupList - it only arranges them and passes
// data + callbacks through, so it stays a thin layout piece rather than a
// second place where list logic could drift out of sync.
export function Sidebar({
  peers,
  groups,
  activePeerId,
  activeGroupId,
  onSelectPeer,
  onSelectGroup,
  onCreateGroup,
}: SidebarProps) {
  return (
    <aside className="sidebar">
      <section className="sidebarSection">
        <div className="sidebarTitle">peers</div>
        <PeerList peers={peers} activePeerId={activePeerId} onSelect={onSelectPeer} />
      </section>

      <section className="sidebarSection">
        <div className="sidebarTitle">groups</div>
        <NewGroupForm onCreate={onCreateGroup} />
        <GroupList groups={groups} activeGroupId={activeGroupId} onSelect={onSelectGroup} />
      </section>
    </aside>
  );
}
