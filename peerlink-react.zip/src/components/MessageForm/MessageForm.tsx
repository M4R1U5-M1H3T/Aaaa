import { useState } from "react";
import "./MessageForm.css";

interface MessageFormProps {
  onSend: (text: string) => void;
}

// The box at the bottom for typing a message. Owns the input's text,
// clears it after sending, and otherwise knows nothing about chats,
// peers, or groups.
export function MessageForm({ onSend }: MessageFormProps) {
  const [text, setText] = useState("");

  function handleSubmit(event: React.FormEvent) {
    event.preventDefault();
    onSend(text);
    setText("");
  }

  return (
    <form className="messageForm" onSubmit={handleSubmit}>
      <input
        className="textInput"
        placeholder="type a message..."
        autoComplete="off"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button className="button mainButton" type="submit">
        send
      </button>
    </form>
  );
}
