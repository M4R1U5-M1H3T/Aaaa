import { useState } from "react";

interface InviteBoxProps {
  members: string[];
  peopleToInvite: string[];
  onInvite: (names: string[]) => void;
}

// The checklist for inviting people into the currently-open group. It owns
// which boxes are checked (pure local UI state) and only calls outward
// once, when "invite selected" is pressed - the parent doesn't need to
// know about checkboxes at all, just the final list of names.
export function InviteBox({ members, peopleToInvite, onInvite }: InviteBoxProps) {
  const [selected, setSelected] = useState<string[]>([]);

  function toggle(name: string) {
    setSelected((current) =>
      current.includes(name) ? current.filter((n) => n !== name) : [...current, name]
    );
  }

  function handleSubmit() {
    onInvite(selected);
    setSelected([]);
  }

  return (
    <div className="inviteBox">
      <div className="inviteLabel">invite to group</div>
      <div className="inviteOptions">
        {peopleToInvite.map((name) => {
          const alreadyMember = members.includes(name);
          return (
            <label key={name}>
              <input
                type="checkbox"
                checked={alreadyMember || selected.includes(name)}
                disabled={alreadyMember}
                onChange={() => toggle(name)}
              />
              {name}
            </label>
          );
        })}
      </div>
      <button className="button mainButton smallButton" onClick={handleSubmit}>
        invite selected
      </button>
    </div>
  );
}
