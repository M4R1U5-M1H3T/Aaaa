import type { Group } from "../../models/Group";

interface GroupListProps {
  groups: Group[];
  activeGroupId: string | null;
  onSelect: (id: string) => void;
}

// Same shape as PeerList, on purpose: one component per list, each with a
// single job, rather than one "list" component that branches internally on
// "is this a peer or a group".
export function GroupList({ groups, activeGroupId, onSelect }: GroupListProps) {
  return (
    <ul className="list">
      {groups.map((group) => (
        <li
          key={group.id}
          className={group.id === activeGroupId ? "activeItem" : ""}
          onClick={() => onSelect(group.id)}
        >
          <span className="itemName"># {group.name}</span>
        </li>
      ))}
    </ul>
  );
}
