import { useState } from "react";
import "./ConnectForm.css";

interface ConnectFormProps {
  onConnect: (host: string, port: string) => void;
}

// The bar for connecting to a new peer. It owns the two text fields itself
// (that's local UI state, nobody else needs it) and only reaches outward
// through onConnect - it has no idea what happens after that call, which is
// what lets the parent swap in a real connection later without this
// component changing at all.
export function ConnectForm({ onConnect }: ConnectFormProps) {
  const [host, setHost] = useState("127.0.0.1");
  const [port, setPort] = useState("");

  function handleConnect() {
    onConnect(host, port);
  }

  return (
    <div className="connectSection">
      <input
        className="textInput"
        placeholder="host"
        value={host}
        onChange={(e) => setHost(e.target.value)}
      />
      <input
        className="textInput smallInput"
        placeholder="port"
        value={port}
        onChange={(e) => setPort(e.target.value)}
      />
      <button className="button mainButton" onClick={handleConnect}>
        connect
      </button>
    </div>
  );
}
