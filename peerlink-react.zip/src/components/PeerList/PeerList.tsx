import type { Peer } from "../../models/Peer";
import "./PeerList.css";

interface PeerListProps {
  peers: Peer[];
  activePeerId: string | null;
  onSelect: (id: string) => void;
}

// Renders the list of peers and reports clicks upward. It never decides
// what "selecting a peer" means (opening a chat, etc.) - that's the
// caller's job, this component only knows how to draw a list.
export function PeerList({ peers, activePeerId, onSelect }: PeerListProps) {
  return (
    <ul className="list">
      {peers.map((peer) => (
        <li
          key={peer.id}
          className={peer.id === activePeerId ? "activeItem" : ""}
          onClick={() => onSelect(peer.id)}
        >
          <span className={`statusDot ${peer.online ? "online" : ""}`}></span>
          <span className="itemName">{peer.name}</span>
          <span className="itemStatus">{peer.online ? "online" : "connecting"}</span>
        </li>
      ))}
    </ul>
  );
}
