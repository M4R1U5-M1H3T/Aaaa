import "./ChatHeader.css";

interface ChatHeaderProps {
  title: string;
  showInviteButton: boolean;
  onToggleInvite: () => void;
}

// The strip above the messages: a title, and (only for a group) an invite
// button. It doesn't know what "invite" does - that's InviteBox's job -
// it just exposes the button and reports clicks.
export function ChatHeader({ title, showInviteButton, onToggleInvite }: ChatHeaderProps) {
  return (
    <div className="chatHeader">
      <div className="chatTitle">{title}</div>
      <div className="chatButtons">
        {showInviteButton && (
          <button className="button" onClick={onToggleInvite}>
            invite
          </button>
        )}
      </div>
    </div>
  );
}
