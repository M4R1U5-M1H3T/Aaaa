import type { ChatMessage } from "../../models/ChatMessage";
import { ChatHeader } from "../ChatHeader/ChatHeader";
import { InviteBox } from "../InviteBox/InviteBox";
import { MessageList } from "../MessageList/MessageList";
import { MessageForm } from "../MessageForm/MessageForm";
import "./ChatArea.css";

interface ChatAreaProps {
  title: string;
  messages: ChatMessage[];
  hasOpenChat: boolean;
  isGroup: boolean;
  groupMembers: string[];
  peopleToInvite: string[];
  showInviteBox: boolean;
  onToggleInvite: () => void;
  onInvite: (names: string[]) => void;
  onSendMessage: (text: string) => void;
}

// Lays out the right column: header, the invite box (only for a group,
// only while open), the message list, and the composer. Like Sidebar, it
// composes smaller pieces rather than rendering any of that content itself.
export function ChatArea({
  title,
  messages,
  hasOpenChat,
  isGroup,
  groupMembers,
  peopleToInvite,
  showInviteBox,
  onToggleInvite,
  onInvite,
  onSendMessage,
}: ChatAreaProps) {
  return (
    <main className="chatArea">
      <ChatHeader title={title} showInviteButton={isGroup} onToggleInvite={onToggleInvite} />

      {showInviteBox && (
        <InviteBox members={groupMembers} peopleToInvite={peopleToInvite} onInvite={onInvite} />
      )}

      <div className="messageArea">
        <MessageList messages={messages} hasOpenChat={hasOpenChat} />
      </div>

      <MessageForm onSend={onSendMessage} />
    </main>
  );
}
