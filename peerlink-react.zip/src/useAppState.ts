import { useState } from "react";
import type { Peer } from "./models/Peer";
import type { Group } from "./models/Group";

const PEOPLE_TO_INVITE = ["alice", "bob"];

const initialPeers: Peer[] = [
  { id: "p1", name: "alice", online: true, messages: [] },
  { id: "p2", name: "bob", online: true, messages: [] },
];

const initialGroups: Group[] = [
  { id: "g1", name: "general", members: ["alice"], messages: [] },
];

/**
 * Owns every piece of mutable state for the mock app and every action that
 * changes it. Nothing here talks to a real network - it's a stand-in for
 * what a real ConnectionManager/GroupManager would do.
 */
export function useAppState() {
  const [peers, setPeers] = useState<Peer[]>(initialPeers);
  const [groups, setGroups] = useState<Group[]>(initialGroups);

  // Only one of these two is ever set at a time - selecting a peer clears
  // the selected group, and vice versa.
  const [selectedPeerId, setSelectedPeerId] = useState<string | null>(null);
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>("g1");

  const [inviteBoxOpenFor, setInviteBoxOpenFor] = useState<string | null>(null);

  function openPeer(id: string) {
    setSelectedPeerId(id);
    setSelectedGroupId(null);
    setInviteBoxOpenFor(null);
  }

  function openGroup(id: string) {
    setSelectedGroupId(id);
    setSelectedPeerId(null);
    setInviteBoxOpenFor(null);
  }

  function toggleInvite(groupId: string) {
    setInviteBoxOpenFor((current) => (current === groupId ? null : groupId));
  }

  function sendMessage(text: string) {
    const trimmed = text.trim();
    if (trimmed === "") return;
    const message = { author: "You", text: trimmed, fromMe: true };

    if (selectedPeerId) {
      setPeers((all) =>
        all.map((p) => (p.id === selectedPeerId ? { ...p, messages: [...p.messages, message] } : p))
      );
    } else if (selectedGroupId) {
      setGroups((all) =>
        all.map((g) => (g.id === selectedGroupId ? { ...g, messages: [...g.messages, message] } : g))
      );
    }
  }

  function createGroup(name: string) {
    const trimmed = name.trim();
    if (trimmed === "") return;
    const group: Group = { id: `g${groups.length + 1}`, name: trimmed, members: [], messages: [] };
    setGroups((all) => [...all, group]);
    openGroup(group.id);
  }

  function connectToPeer(host: string, port: string) {
    if (host.trim() === "" || port.trim() === "") return;
    const id = `p${peers.length + 1}`;
    const peer: Peer = { id, name: `${host}:${port}`, online: false, messages: [] };
    setPeers((all) => [...all, peer]);
    // Fakes what a real handshake would eventually resolve to.
    window.setTimeout(() => {
      setPeers((all) => all.map((p) => (p.id === id ? { ...p, online: true } : p)));
    }, 700);
  }

  function invite(groupId: string, names: string[]) {
    setGroups((all) =>
      all.map((g) => (g.id === groupId ? { ...g, members: [...g.members, ...names] } : g))
    );
    setInviteBoxOpenFor(null);
  }

  return {
    peers,
    groups,
    selectedPeerId,
    selectedGroupId,
    inviteBoxOpenFor,
    peopleToInvite: PEOPLE_TO_INVITE,
    openPeer,
    openGroup,
    toggleInvite,
    sendMessage,
    createGroup,
    connectToPeer,
    invite,
  };
}
