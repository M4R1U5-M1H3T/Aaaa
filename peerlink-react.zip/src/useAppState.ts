import { useState } from "react";
import type { Peer } from "./models/Peer";
import type { Group } from "./models/Group";
import type { ActiveThread } from "./models/ActiveThread";

const PEOPLE_TO_INVITE = ["alice", "bob"];

const initialPeers: Peer[] = [
  { id: "p1", name: "alice", online: true, messages: [] },
  { id: "p2", name: "bob", online: true, messages: [] },
];

const initialGroups: Group[] = [
  { id: "g1", name: "general", members: ["alice"], messages: [] },
];

/**
 * Owns every piece of mutable state for the mock app and every action that
 * changes it. Nothing here talks to a real network - it's a stand-in for
 * what a real ConnectionManager/GroupManager would do. Components never
 * touch this state directly; they only receive plain data and callback
 * props from whoever calls this hook (App), which is what keeps them easy
 * to reuse or swap out later.
 */
export function useAppState() {
  const [peers, setPeers] = useState<Peer[]>(initialPeers);
  const [groups, setGroups] = useState<Group[]>(initialGroups);
  const [activeThread, setActiveThread] = useState<ActiveThread>({ type: "group", id: "g1" });
  const [inviteBoxOpenFor, setInviteBoxOpenFor] = useState<string | null>(null);

  function openChat(type: "peer" | "group", id: string) {
    setActiveThread({ type, id });
    setInviteBoxOpenFor(null);
  }

  function toggleInvite(groupId: string) {
    setInviteBoxOpenFor((current) => (current === groupId ? null : groupId));
  }

  function sendMessage(text: string) {
    const trimmed = text.trim();
    if (!activeThread || trimmed === "") return;
    const message = { author: "You", text: trimmed, fromMe: true };

    if (activeThread.type === "peer") {
      setPeers((all) =>
        all.map((p) => (p.id === activeThread.id ? { ...p, messages: [...p.messages, message] } : p))
      );
    } else {
      setGroups((all) =>
        all.map((g) => (g.id === activeThread.id ? { ...g, messages: [...g.messages, message] } : g))
      );
    }
  }

  function createGroup(name: string) {
    const trimmed = name.trim();
    if (trimmed === "") return;
    const group: Group = { id: `g${groups.length + 1}`, name: trimmed, members: [], messages: [] };
    setGroups((all) => [...all, group]);
    openChat("group", group.id);
  }

  function connectToPeer(host: string, port: string) {
    if (host.trim() === "" || port.trim() === "") return;
    const id = `p${peers.length + 1}`;
    const peer: Peer = { id, name: `${host}:${port}`, online: false, messages: [] };
    setPeers((all) => [...all, peer]);
    // Fakes what a real handshake would eventually resolve to.
    window.setTimeout(() => {
      setPeers((all) => all.map((p) => (p.id === id ? { ...p, online: true } : p)));
    }, 700);
  }

  function invite(groupId: string, names: string[]) {
    setGroups((all) =>
      all.map((g) => (g.id === groupId ? { ...g, members: [...g.members, ...names] } : g))
    );
    setInviteBoxOpenFor(null);
  }

  return {
    peers,
    groups,
    activeThread,
    inviteBoxOpenFor,
    peopleToInvite: PEOPLE_TO_INVITE,
    openChat,
    toggleInvite,
    sendMessage,
    createGroup,
    connectToPeer,
    invite,
  };
}
