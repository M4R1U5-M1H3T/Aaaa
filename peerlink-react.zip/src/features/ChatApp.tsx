import { useState } from "react";
import type { Peer } from "../models/Peer";
import type { Group } from "../models/Group";
import { TopBar } from "../components/TopBar/TopBar";
import { ConnectForm } from "../components/ConnectForm/ConnectForm";
import { Sidebar } from "../components/Sidebar/Sidebar";
import { ChatArea } from "../components/ChatArea/ChatArea";
import "./ChatApp.css";

const PEOPLE_TO_INVITE = ["alice", "bob"];

const initialPeers: Peer[] = [
  { id: "p1", name: "alice", online: true, messages: [] },
  { id: "p2", name: "bob", online: true, messages: [] },
];

const initialGroups: Group[] = [
  { id: "g1", name: "general", members: ["alice"], messages: [] },
];

// Assembles the whole app and owns all of its state directly - this is the
// only component that calls useState. Everything below it only ever sees
// plain props and callbacks, so the state could later be swapped for a
// real backend without touching a single component.
export function ChatApp() {
  const [peers, setPeers] = useState<Peer[]>(initialPeers);
  const [groups, setGroups] = useState<Group[]>(initialGroups);

  // Only one of these two is ever set at a time - selecting a peer clears
  // the selected group, and vice versa.
  const [selectedPeerId, setSelectedPeerId] = useState<string | null>(null);
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>("g1");

  const [inviteBoxOpenFor, setInviteBoxOpenFor] = useState<string | null>(null);

  const activePeer = peers.find((p) => p.id === selectedPeerId);
  const activeGroup = groups.find((g) => g.id === selectedGroupId);

  function openPeer(id: string) {
    setSelectedPeerId(id);
    setSelectedGroupId(null);
    setInviteBoxOpenFor(null);
  }

  function openGroup(id: string) {
    setSelectedGroupId(id);
    setSelectedPeerId(null);
    setInviteBoxOpenFor(null);
  }

  function toggleInvite(groupId: string) {
    setInviteBoxOpenFor((current) => (current === groupId ? null : groupId));
  }

  function sendMessage(text: string) {
    const trimmed = text.trim();
    if (trimmed === "") return;
    const message = { author: "You", text: trimmed, fromMe: true };

    if (selectedPeerId) {
      setPeers((all) =>
        all.map((p) => (p.id === selectedPeerId ? { ...p, messages: [...p.messages, message] } : p))
      );
    } else if (selectedGroupId) {
      setGroups((all) =>
        all.map((g) => (g.id === selectedGroupId ? { ...g, messages: [...g.messages, message] } : g))
      );
    }
  }

  function createGroup(name: string) {
    const trimmed = name.trim();
    if (trimmed === "") return;
    const group: Group = { id: `g${groups.length + 1}`, name: trimmed, members: [], messages: [] };
    setGroups((all) => [...all, group]);
    openGroup(group.id);
  }

  function connectToPeer(host: string, port: string) {
    if (host.trim() === "" || port.trim() === "") return;
    const id = `p${peers.length + 1}`;
    const peer: Peer = { id, name: `${host}:${port}`, online: false, messages: [] };
    setPeers((all) => [...all, peer]);
    // Fakes what a real handshake would eventually resolve to.
    window.setTimeout(() => {
      setPeers((all) => all.map((p) => (p.id === id ? { ...p, online: true } : p)));
    }, 700);
  }

  function invite(groupId: string, names: string[]) {
    setGroups((all) =>
      all.map((g) => (g.id === groupId ? { ...g, members: [...g.members, ...names] } : g))
    );
    setInviteBoxOpenFor(null);
  }

  const title = activePeer
    ? activePeer.name
    : activeGroup
      ? `# ${activeGroup.name} (${activeGroup.members.length + 1} members)`
      : "select a peer or group";

  const messages = activePeer?.messages ?? activeGroup?.messages ?? [];

  return (
    <div className="appContainer">
      <TopBar />
      <ConnectForm onConnect={connectToPeer} />

      <div className="mainArea">
        <Sidebar
          peers={peers}
          groups={groups}
          activePeerId={selectedPeerId}
          activeGroupId={selectedGroupId}
          onSelectPeer={openPeer}
          onSelectGroup={openGroup}
          onCreateGroup={createGroup}
        />

        <ChatArea
          title={title}
          messages={messages}
          hasOpenChat={activePeer !== undefined || activeGroup !== undefined}
          isGroup={activeGroup !== undefined}
          groupMembers={activeGroup?.members ?? []}
          peopleToInvite={PEOPLE_TO_INVITE}
          showInviteBox={activeGroup !== undefined && inviteBoxOpenFor === activeGroup.id}
          onToggleInvite={() => activeGroup && toggleInvite(activeGroup.id)}
          onInvite={(names) => activeGroup && invite(activeGroup.id, names)}
          onSendMessage={sendMessage}
        />
      </div>
    </div>
  );
}
