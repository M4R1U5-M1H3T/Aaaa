import { useAppState } from "../useAppState";
import { TopBar } from "../components/TopBar/TopBar";
import { ConnectForm } from "../components/ConnectForm/ConnectForm";
import { Sidebar } from "../components/Sidebar/Sidebar";
import { ChatArea } from "../components/ChatArea/ChatArea";
import "./ChatApp.css";

// Assembles the whole app: this is the only place that calls useAppState.
// Every component below only ever sees plain props and callbacks, so the
// state could later be swapped for a real backend without touching a
// single component.
export function ChatApp() {
  const state = useAppState();

  const activePeer = state.peers.find((p) => p.id === state.selectedPeerId);
  const activeGroup = state.groups.find((g) => g.id === state.selectedGroupId);

  const title = activePeer
    ? activePeer.name
    : activeGroup
      ? `# ${activeGroup.name} (${activeGroup.members.length + 1} members)`
      : "select a peer or group";

  const messages = activePeer?.messages ?? activeGroup?.messages ?? [];

  return (
    <div className="appContainer">
      <TopBar />
      <ConnectForm onConnect={state.connectToPeer} />

      <div className="mainArea">
        <Sidebar
          peers={state.peers}
          groups={state.groups}
          activePeerId={state.selectedPeerId}
          activeGroupId={state.selectedGroupId}
          onSelectPeer={state.openPeer}
          onSelectGroup={state.openGroup}
          onCreateGroup={state.createGroup}
        />

        <ChatArea
          title={title}
          messages={messages}
          hasOpenChat={activePeer !== undefined || activeGroup !== undefined}
          isGroup={activeGroup !== undefined}
          groupMembers={activeGroup?.members ?? []}
          peopleToInvite={state.peopleToInvite}
          showInviteBox={activeGroup !== undefined && state.inviteBoxOpenFor === activeGroup.id}
          onToggleInvite={() => activeGroup && state.toggleInvite(activeGroup.id)}
          onInvite={(names) => activeGroup && state.invite(activeGroup.id, names)}
          onSendMessage={state.sendMessage}
        />
      </div>
    </div>
  );
}
