import type { ChatMessage } from "./ChatMessage";

// A direct, one-to-one connection to another user.
export interface Peer {
  id: string;
  name: string;
  online: boolean;
  messages: ChatMessage[];
}
