import type { ChatMessage } from "./ChatMessage";

// A group chat with a name and a list of member names (not counting "you").
export interface Group {
  id: string;
  name: string;
  members: string[];
  messages: ChatMessage[];
}
