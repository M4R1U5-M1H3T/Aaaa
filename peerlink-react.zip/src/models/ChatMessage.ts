// A single chat message, shown either in a peer's thread or a group's thread.
export interface ChatMessage {
  author: string;
  text: string;
  fromMe: boolean;
}
