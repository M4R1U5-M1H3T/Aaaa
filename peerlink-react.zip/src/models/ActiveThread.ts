// Which conversation is currently open: a specific peer, a specific group,
// or nothing yet (before the user has picked anything).
export type ActiveThread = { type: "peer" | "group"; id: string } | null;
