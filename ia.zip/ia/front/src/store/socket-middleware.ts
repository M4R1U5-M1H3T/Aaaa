/*
    What should be done:

    - createListenerMiddleware()
	- startAppListening({actionCreator: <<name of action>>, effect: <<callback function>>})

*/