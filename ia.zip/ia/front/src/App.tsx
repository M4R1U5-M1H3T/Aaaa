import { ChatApp } from "./features";

export const App = () => {
  return (
      <ChatApp />
  );
};
