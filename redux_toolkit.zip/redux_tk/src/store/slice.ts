import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import type { Peer, Group } from "../models";

export interface ChatState {
  peers: Peer[];
  groups: Group[];
  selectedPeerId: string | null;
  selectedGroupId: string | null;
  inviteBoxOpenFor: string | null;
  peopleToInvite: string[];
}

const initialState: ChatState = {
  peers: [
    { id: "p1", name: "alice", online: true, messages: [] },
    { id: "p2", name: "bob", online: false, messages: [] },
  ],
  groups: [{ id: "g1", name: "general", members: ["alice"], messages: [] }],
  selectedPeerId: null,
  selectedGroupId: "g1",
  inviteBoxOpenFor: null,
  peopleToInvite: ["alice", "bob"],
};

const chatSlice = createSlice({
  name: "chat",
  initialState,
  reducers: {
    openPeer: (state, action: PayloadAction<string>) => {
      state.selectedPeerId = action.payload;
      state.selectedGroupId = null;
      state.inviteBoxOpenFor = null;
    },

    openGroup: (state, action: PayloadAction<string>) => {
      state.selectedGroupId = action.payload;
      state.selectedPeerId = null;
      state.inviteBoxOpenFor = null;
    },

    toggleInvite: (state, action: PayloadAction<string>) => {
      state.inviteBoxOpenFor =
        state.inviteBoxOpenFor === action.payload ? null : action.payload;
    },

    sendMessage: (state, action: PayloadAction<string>) => {
      const trimmed = action.payload.trim();
      if (trimmed === "") return;
      const message = { author: "You", text: trimmed, fromMe: true };

      if (state.selectedPeerId) {
        const peer = state.peers.find((p) => p.id === state.selectedPeerId);
        peer?.messages.push(message);
      } else if (state.selectedGroupId) {
        const group = state.groups.find((g) => g.id === state.selectedGroupId);
        group?.messages.push(message);
      }
    },

    createGroup: (state, action: PayloadAction<string>) => {
      const trimmed = action.payload.trim();
      if (trimmed === "") return;
      const group: Group = {
        id: `g${state.groups.length + 1}`,
        name: trimmed,
        members: [],
        messages: [],
      };
      state.groups.push(group);
      state.selectedGroupId = group.id;
      state.selectedPeerId = null;
      state.inviteBoxOpenFor = null;
    },

    addPeer: (state, action: PayloadAction<Peer>) => {
      state.peers.push(action.payload);
    },

    setPeerOnline: (state, action: PayloadAction<string>) => {
      const peer = state.peers.find((p) => p.id === action.payload);
      if (peer) peer.online = true;
    },

    invite: {
      prepare: (groupId: string, names: string[]) => ({
        payload: { groupId, names },
      }),
      reducer: (
        state,
        action: PayloadAction<{ groupId: string; names: string[] }>
      ) => {
        const group = state.groups.find((g) => g.id === action.payload.groupId);
        if (group) group.members.push(...action.payload.names);
        state.inviteBoxOpenFor = null;
      },
    },
  },
});

export const {
  openPeer,
  openGroup,
  toggleInvite,
  sendMessage,
  createGroup,
  addPeer,
  setPeerOnline,
  invite,
} = chatSlice.actions;

export const chatReducer = chatSlice.reducer;
