// here instead of this file I should have multiple specialized mock files/hooks for each functionality.
// I should extract all the mock data from ChatApp.tsx and put it in these files.
// (all the const from ChatApp.tsx, until the return statement)