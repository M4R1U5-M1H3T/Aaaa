export interface ConnectSectionProps {
  onConnect: (host: string, port: string) => void;
};
