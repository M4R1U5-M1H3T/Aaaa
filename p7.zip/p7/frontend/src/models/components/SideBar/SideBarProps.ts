import type { Peer, Group } from "../../../models";

export interface SideBarProps {
  peers: Peer[];
  groups: Group[];
  activePeerId: string | null;
  activeGroupId: string | null;
  onSelectPeer: (id: string) => void;
  onSelectGroup: (id: string) => void;
  onCreateGroup: (name: string) => void;
};
