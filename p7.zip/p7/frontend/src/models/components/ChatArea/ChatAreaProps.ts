import type { ChatMessage } from "../../../models";

export interface ChatAreaProps {
  title: string;
  messages: ChatMessage[];
  hasOpenChat: boolean;
  isGroup: boolean;
  groupMembers: string[];
  peopleToInvite: string[];
  showInviteBox: boolean;
  onToggleInvite: () => void;
  onInvite: (names: string[]) => void;
  onSendMessage: (text: string) => void;
};
