import { useState } from "react";
import type { Peer, Group } from "../../models";
import { TopBar, ConnectSection, Sidebar, ChatArea } from "../../components";
import "./ChatApp.css";

const PEOPLE_TO_INVITE = ["alice", "bob"];

const initialPeers: Peer[] = [
  { id: "p1", name: "alice", online: true, messages: [] },
  { id: "p2", name: "bob", online: false, messages: [] },
];

const initialGroups: Group[] = [
  { id: "g1", name: "general", members: ["alice"], messages: [] },
];

export const ChatApp = () => {
  const [peers, setPeers] = useState<Peer[]>(initialPeers);
  const [groups, setGroups] = useState<Group[]>(initialGroups);

  const [selectedPeerId, setSelectedPeerId] = useState<string | null>(null);
  const [selectedGroupId, setSelectedGroupId] = useState<string | null>("g1");

  const [inviteBoxOpenFor, setInviteBoxOpenFor] = useState<string | null>(null);

  const activePeer = peers.find((p) => p.id === selectedPeerId);
  const activeGroup = groups.find((g) => g.id === selectedGroupId);

  const openPeer = (id: string) => {
    setSelectedPeerId(id);
    setSelectedGroupId(null);
    setInviteBoxOpenFor(null);
  };

  const openGroup = (id: string) => {
    setSelectedGroupId(id);
    setSelectedPeerId(null);
    setInviteBoxOpenFor(null);
  };

  const toggleInvite = (groupId: string) => {
    setInviteBoxOpenFor((current) => (current === groupId ? null : groupId));
  };

  const sendMessage = (text: string) => {
    const trimmed = text.trim();
    if (trimmed === "") return;
    const message = { author: "You", text: trimmed, fromMe: true };

    if (selectedPeerId) {
      setPeers((all) =>
        all.map((p) => (p.id === selectedPeerId ? { ...p, messages: [...p.messages, message] } : p))
      );
    } else if (selectedGroupId) {
      setGroups((all) =>
        all.map((g) => (g.id === selectedGroupId ? { ...g, messages: [...g.messages, message] } : g))
      );
    }
  };

  const createGroup = (name: string) => {
    const trimmed = name.trim();
    if (trimmed === "") return;
    const group: Group = { id: `g${groups.length + 1}`, name: trimmed, members: [], messages: [] };
    setGroups((all) => [...all, group]);
    openGroup(group.id);
  };

  const connectToPeer = (host: string, port: string) => {
    if (host.trim() === "" || port.trim() === "") return;
    const id = `p${peers.length + 1}`;
    const peer: Peer = { id, name: `${host}:${port}`, online: false, messages: [] };
    setPeers((all) => [...all, peer]);
    window.setTimeout(() => {
      setPeers((all) => all.map((p) => (p.id === id ? { ...p, online: true } : p)));
    }, 700);
  };

  const invite = (groupId: string, names: string[]) => {
    setGroups((all) =>
      all.map((g) => (g.id === groupId ? { ...g, members: [...g.members, ...names] } : g))
    );
    setInviteBoxOpenFor(null);
  };

  const title = activePeer ? activePeer.name : activeGroup ?
      `# ${activeGroup.name} (${activeGroup.members.length + 1} members)` : "select a peer or group";

  const messages = activePeer?.messages ?? activeGroup?.messages ?? [];

  return (
    <>
    <div className="appContainer">
      <TopBar />
      <ConnectSection onConnect={connectToPeer} />

      <div className="mainArea">
        <Sidebar
          peers={peers}
          groups={groups}
          activePeerId={selectedPeerId}
          activeGroupId={selectedGroupId}
          onSelectPeer={openPeer}
          onSelectGroup={openGroup}
          onCreateGroup={createGroup}
        />

        <ChatArea
          title={title}
          messages={messages}
          hasOpenChat={activePeer !== undefined || activeGroup !== undefined}
          isGroup={activeGroup !== undefined}
          groupMembers={activeGroup?.members ?? []}
          peopleToInvite={PEOPLE_TO_INVITE}
          showInviteBox={activeGroup !== undefined && inviteBoxOpenFor === activeGroup.id}
          onToggleInvite={() => activeGroup && toggleInvite(activeGroup.id)}
          onInvite={(names) => activeGroup && invite(activeGroup.id, names)}
          onSendMessage={sendMessage}
        />
      </div>
    </div>
    </>
  );
};
