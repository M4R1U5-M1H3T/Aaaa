import { useConnectHook } from "./useConnectHook";
import type { ConnectSectionProps } from "../../models";
import "./ConnectSection.css";

export const ConnectSection = ({ onConnect }: ConnectSectionProps) => {
  const { host, setHost, port, setPort, handleConnect } = useConnectHook(onConnect);

  return (
    <div className="connectSection">
      <input
        className="textInput"
        placeholder="host"
        value={host}
        onChange={(e) => setHost(e.target.value)}
      />
      <input
        className="textInput smallInput"
        placeholder="port"
        value={port}
        onChange={(e) => setPort(e.target.value)}
      />
      <button className="button mainButton" onClick={handleConnect}>
        connect
      </button>
    </div>
  );
};
