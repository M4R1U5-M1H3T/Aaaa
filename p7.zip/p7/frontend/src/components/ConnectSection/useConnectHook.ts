import { useState } from 'react';

export const useConnectHook = (onConnect: (host: string, port: string) => void) => {
  const [host, setHost] = useState("127.0.0.1");
  const [port, setPort] = useState("");

  const handleConnect = () => {
    onConnect(host, port);
  };

  return { host, setHost, port, setPort, handleConnect };
};
