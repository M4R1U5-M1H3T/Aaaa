import type { ChatMessage } from "../../models";
import { ChatHeader, InviteBox, MessageList, MessageForm } from "../../components";
import "./ChatArea.css";

interface ChatAreaProps {
  title: string;
  messages: ChatMessage[];
  hasOpenChat: boolean;
  isGroup: boolean;
  groupMembers: string[];
  peopleToInvite: string[];
  showInviteBox: boolean;
  onToggleInvite: () => void;
  onInvite: (names: string[]) => void;
  onSendMessage: (text: string) => void;
}

export const ChatArea = ({title, messages, hasOpenChat, isGroup, groupMembers, peopleToInvite, showInviteBox, onToggleInvite, onInvite, onSendMessage,}: ChatAreaProps) => {
  return (
    <main className="chatArea">
      <ChatHeader title={title} showInviteButton={isGroup} onToggleInvite={onToggleInvite} />

      {showInviteBox && (
        <InviteBox members={groupMembers} peopleToInvite={peopleToInvite} onInvite={onInvite} />
      )}

      <div className="messageArea">
        <MessageList messages={messages} hasOpenChat={hasOpenChat} />
      </div>

      <MessageForm onSend={onSendMessage} />
    </main>
  );
};
