import type { PeerListProps } from "../../models";
import "./PeerList.css";

export const PeerList = ({ peers, activePeerId, onSelect }: PeerListProps) => {
  return (
    <ul className="list">
      {peers.map((peer) => (
        <li
          key={peer.id}
          className={peer.id === activePeerId ? "activeItem" : ""}
          onClick={() => onSelect(peer.id)}
        >
          <span className={`statusDot ${peer.online ? "online" : ""}`}></span>
          <span className="itemName">{peer.name}</span>
          <span className="itemStatus">{peer.online ? "online" : "connecting"}</span>
        </li>
      ))}
    </ul>
  );
};
