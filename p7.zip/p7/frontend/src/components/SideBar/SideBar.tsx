import type { SideBarProps } from "../../models";
import { PeerList, GroupList, NewGroupForm } from "../../components";
import "./SideBar.css";

export const Sidebar = ({peers, groups, activePeerId, activeGroupId, onSelectPeer, onSelectGroup, onCreateGroup,}: SideBarProps) => {
  return (
    <aside className="sidebar">
      <section className="sidebarSection">
        <div className="sidebarTitle">peers</div>
        <PeerList peers={peers} activePeerId={activePeerId} onSelect={onSelectPeer} />
      </section>

      <section className="sidebarSection">
        <div className="sidebarTitle">groups</div>
        <NewGroupForm onCreate={onCreateGroup} />
        <GroupList groups={groups} activeGroupId={activeGroupId} onSelect={onSelectGroup} />
      </section>
    </aside>
  );
};
