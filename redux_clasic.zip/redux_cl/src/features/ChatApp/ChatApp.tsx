import { TopBar, ConnectSection, Sidebar, ChatArea } from "../../components";
import "./ChatApp.css";

export const ChatApp = () => {
  return (
    <>
      <div className="appContainer">
        <TopBar />
        <ConnectSection />

        <div className="mainArea">
          <Sidebar />
          <ChatArea />
        </div>
      </div>
    </>
  );
};
