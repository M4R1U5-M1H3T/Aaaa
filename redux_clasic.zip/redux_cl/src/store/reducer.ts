import type { Peer, Group } from "../models";
import {
  OPEN_PEER,
  OPEN_GROUP,
  TOGGLE_INVITE,
  SEND_MESSAGE,
  CREATE_GROUP,
  ADD_PEER,
  SET_PEER_ONLINE,
  INVITE,
  type ChatAction,
} from "./actions";

export interface ChatState {
  peers: Peer[];
  groups: Group[];
  selectedPeerId: string | null;
  selectedGroupId: string | null;
  inviteBoxOpenFor: string | null;
  peopleToInvite: string[];
}

const initialState: ChatState = {
  peers: [
    { id: "p1", name: "alice", online: true, messages: [] },
    { id: "p2", name: "bob", online: false, messages: [] },
  ],
  groups: [{ id: "g1", name: "general", members: ["alice"], messages: [] }],
  selectedPeerId: null,
  selectedGroupId: "g1",
  inviteBoxOpenFor: null,
  peopleToInvite: ["alice", "bob"],
};

export const chatReducer = (
  state: ChatState = initialState,
  action: ChatAction
): ChatState => {
  switch (action.type) {
    case OPEN_PEER:
      return {
        ...state,
        selectedPeerId: action.payload.id,
        selectedGroupId: null,
        inviteBoxOpenFor: null,
      };

    case OPEN_GROUP:
      return {
        ...state,
        selectedGroupId: action.payload.id,
        selectedPeerId: null,
        inviteBoxOpenFor: null,
      };

    case TOGGLE_INVITE:
      return {
        ...state,
        inviteBoxOpenFor:
          state.inviteBoxOpenFor === action.payload.groupId
            ? null
            : action.payload.groupId,
      };

    case SEND_MESSAGE: {
      const trimmed = action.payload.text.trim();
      if (trimmed === "") return state;
      const message = { author: "You", text: trimmed, fromMe: true };

      if (state.selectedPeerId) {
        return {
          ...state,
          peers: state.peers.map((p) =>
            p.id === state.selectedPeerId
              ? { ...p, messages: [...p.messages, message] }
              : p
          ),
        };
      }
      if (state.selectedGroupId) {
        return {
          ...state,
          groups: state.groups.map((g) =>
            g.id === state.selectedGroupId
              ? { ...g, messages: [...g.messages, message] }
              : g
          ),
        };
      }
      return state;
    }

    case CREATE_GROUP: {
      const trimmed = action.payload.name.trim();
      if (trimmed === "") return state;
      const group: Group = {
        id: `g${state.groups.length + 1}`,
        name: trimmed,
        members: [],
        messages: [],
      };
      return {
        ...state,
        groups: [...state.groups, group],
        selectedGroupId: group.id,
        selectedPeerId: null,
        inviteBoxOpenFor: null,
      };
    }

    case ADD_PEER:
      return { ...state, peers: [...state.peers, action.payload.peer] };

    case SET_PEER_ONLINE:
      return {
        ...state,
        peers: state.peers.map((p) =>
          p.id === action.payload.id ? { ...p, online: true } : p
        ),
      };

    case INVITE:
      return {
        ...state,
        groups: state.groups.map((g) =>
          g.id === action.payload.groupId
            ? { ...g, members: [...g.members, ...action.payload.names] }
            : g
        ),
        inviteBoxOpenFor: null,
      };

    default:
      return state;
  }
};
