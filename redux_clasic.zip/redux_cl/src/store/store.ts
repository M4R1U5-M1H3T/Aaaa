import { createStore } from "redux";
import { chatReducer } from "./reducer";

export const store = createStore(chatReducer);

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
