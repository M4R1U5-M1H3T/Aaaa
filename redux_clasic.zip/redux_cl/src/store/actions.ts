import type { Peer } from "../models";

// Action type constants
export const OPEN_PEER = "OPEN_PEER";
export const OPEN_GROUP = "OPEN_GROUP";
export const TOGGLE_INVITE = "TOGGLE_INVITE";
export const SEND_MESSAGE = "SEND_MESSAGE";
export const CREATE_GROUP = "CREATE_GROUP";
export const ADD_PEER = "ADD_PEER";
export const SET_PEER_ONLINE = "SET_PEER_ONLINE";
export const INVITE = "INVITE";

// Action interfaces
interface OpenPeerAction {
  type: typeof OPEN_PEER;
  payload: { id: string };
}

interface OpenGroupAction {
  type: typeof OPEN_GROUP;
  payload: { id: string };
}

interface ToggleInviteAction {
  type: typeof TOGGLE_INVITE;
  payload: { groupId: string };
}

interface SendMessageAction {
  type: typeof SEND_MESSAGE;
  payload: { text: string };
}

interface CreateGroupAction {
  type: typeof CREATE_GROUP;
  payload: { name: string };
}

interface AddPeerAction {
  type: typeof ADD_PEER;
  payload: { peer: Peer };
}

interface SetPeerOnlineAction {
  type: typeof SET_PEER_ONLINE;
  payload: { id: string };
}

interface InviteAction {
  type: typeof INVITE;
  payload: { groupId: string; names: string[] };
}

export type ChatAction =
  | OpenPeerAction
  | OpenGroupAction
  | ToggleInviteAction
  | SendMessageAction
  | CreateGroupAction
  | AddPeerAction
  | SetPeerOnlineAction
  | InviteAction;

// Action creators
export const openPeer = (id: string): OpenPeerAction => ({
  type: OPEN_PEER,
  payload: { id },
});

export const openGroup = (id: string): OpenGroupAction => ({
  type: OPEN_GROUP,
  payload: { id },
});

export const toggleInvite = (groupId: string): ToggleInviteAction => ({
  type: TOGGLE_INVITE,
  payload: { groupId },
});

export const sendMessage = (text: string): SendMessageAction => ({
  type: SEND_MESSAGE,
  payload: { text },
});

export const createGroup = (name: string): CreateGroupAction => ({
  type: CREATE_GROUP,
  payload: { name },
});

export const addPeer = (peer: Peer): AddPeerAction => ({
  type: ADD_PEER,
  payload: { peer },
});

export const setPeerOnline = (id: string): SetPeerOnlineAction => ({
  type: SET_PEER_ONLINE,
  payload: { id },
});

export const invite = (groupId: string, names: string[]): InviteAction => ({
  type: INVITE,
  payload: { groupId, names },
});
