import type { RootState } from "./store";

export const selectPeers = (state: RootState) => state.peers;
export const selectGroups = (state: RootState) => state.groups;
export const selectSelectedPeerId = (state: RootState) => state.selectedPeerId;
export const selectSelectedGroupId = (state: RootState) => state.selectedGroupId;
export const selectPeopleToInvite = (state: RootState) => state.peopleToInvite;

export const selectActivePeer = (state: RootState) =>
  state.peers.find((p) => p.id === state.selectedPeerId);

export const selectActiveGroup = (state: RootState) =>
  state.groups.find((g) => g.id === state.selectedGroupId);

export const selectHasOpenChat = (state: RootState) =>
  selectActivePeer(state) !== undefined || selectActiveGroup(state) !== undefined;

export const selectIsGroup = (state: RootState) =>
  selectActiveGroup(state) !== undefined;

export const selectTitle = (state: RootState) => {
  const activePeer = selectActivePeer(state);
  const activeGroup = selectActiveGroup(state);
  if (activePeer) return activePeer.name;
  if (activeGroup)
    return `# ${activeGroup.name} (${activeGroup.members.length + 1} members)`;
  return "select a peer or group";
};

export const selectMessages = (state: RootState) => {
  const activePeer = selectActivePeer(state);
  const activeGroup = selectActiveGroup(state);
  return activePeer?.messages ?? activeGroup?.messages ?? [];
};

export const selectGroupMembers = (state: RootState) =>
  selectActiveGroup(state)?.members ?? [];

export const selectShowInviteBox = (state: RootState) => {
  const activeGroup = selectActiveGroup(state);
  return activeGroup !== undefined && state.inviteBoxOpenFor === activeGroup.id;
};
