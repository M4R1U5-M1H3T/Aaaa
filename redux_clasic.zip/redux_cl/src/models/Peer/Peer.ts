import type { ChatMessage } from '../ChatMessage';

export interface Peer {
  id: string;
  name: string;
  online: boolean;
  messages: ChatMessage[];
}