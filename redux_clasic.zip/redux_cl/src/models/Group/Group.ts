import type { ChatMessage } from '../ChatMessage';

export interface Group {
  id: string;
  name: string;
  members: string[];
  messages: ChatMessage[];
}