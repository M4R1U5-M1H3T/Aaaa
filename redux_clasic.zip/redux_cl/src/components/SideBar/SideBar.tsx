import { PeerList, GroupList, NewGroupForm } from "../../components";
import "./SideBar.css";

export const Sidebar = () => {
  return (
    <aside className="sidebar">
      <section className="sidebarSection">
        <div className="sidebarTitle">peers</div>
        <PeerList />
      </section>

      <section className="sidebarSection">
        <div className="sidebarTitle">groups</div>
        <NewGroupForm />
        <GroupList />
      </section>
    </aside>
  );
};
