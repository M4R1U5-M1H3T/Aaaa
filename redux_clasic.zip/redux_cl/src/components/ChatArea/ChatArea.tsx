import { ChatHeader, InviteBox, MessageList, MessageForm } from "../../components";
import { useAppSelector, selectShowInviteBox } from "../../store";
import "./ChatArea.css";

export const ChatArea = () => {
  const showInviteBox = useAppSelector(selectShowInviteBox);

  return (
    <main className="chatArea">
      <ChatHeader />

      {showInviteBox && <InviteBox />}

      <div className="messageArea">
        <MessageList />
      </div>

      <MessageForm />
    </main>
  );
};
