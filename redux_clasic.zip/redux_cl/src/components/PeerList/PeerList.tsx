import { useAppDispatch, useAppSelector, openPeer, selectPeers, selectSelectedPeerId } from "../../store";
import "./PeerList.css";

export const PeerList = () => {
  const dispatch = useAppDispatch();
  const peers = useAppSelector(selectPeers);
  const activePeerId = useAppSelector(selectSelectedPeerId);

  return (
    <ul className="list">
      {peers.map((peer) => (
        <li
          key={peer.id}
          className={peer.id === activePeerId ? "activeItem" : ""}
          onClick={() => dispatch(openPeer(peer.id))}
        >
          <span className={`statusDot ${peer.online ? "online" : ""}`}></span>
          <span className="itemName">{peer.name}</span>
          <span className="itemStatus">{peer.online ? "online" : "connecting"}</span>
        </li>
      ))}
    </ul>
  );
};
