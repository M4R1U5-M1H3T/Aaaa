import { useState } from "react";
import { useAppDispatch, sendMessage } from "../../store";

export const useMessageHook = () => {
  const dispatch = useAppDispatch();
  const [text, setText] = useState("");

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    dispatch(sendMessage(text));
    setText("");
  };

  return { text, setText, handleSubmit };
};
