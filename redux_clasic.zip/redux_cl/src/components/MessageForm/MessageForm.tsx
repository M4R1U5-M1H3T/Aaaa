import { useMessageHook } from "./useMessageHook";
import "./MessageForm.css";

export const MessageForm = () => {
  const { text, setText, handleSubmit } = useMessageHook();

  return (
    <form className="messageForm" onSubmit={handleSubmit}>
      <input
        className="textInput"
        placeholder="type a message..."
        autoComplete="off"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button className="button mainButton" type="submit">
        send
      </button>
    </form>
  );
};
