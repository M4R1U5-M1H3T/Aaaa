import { useAppDispatch, useAppSelector, openGroup, selectGroups, selectSelectedGroupId } from "../../store";
import "./GroupList.css";

export const GroupList = () => {
  const dispatch = useAppDispatch();
  const groups = useAppSelector(selectGroups);
  const activeGroupId = useAppSelector(selectSelectedGroupId);

  return (
    <ul className="list">
      {groups.map((group) => (
        <li
          key={group.id}
          className={group.id === activeGroupId ? "activeItem" : ""}
          onClick={() => dispatch(openGroup(group.id))}
        >
          <span className="itemName"># {group.name}</span>
        </li>
      ))}
    </ul>
  );
};
