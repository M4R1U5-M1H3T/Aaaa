import { useState } from "react";
import { useAppDispatch, createGroup } from "../../store";

export const useGroupHook = () => {
  const dispatch = useAppDispatch();
  const [name, setName] = useState("");

  const handleCreate = () => {
    dispatch(createGroup(name));
    setName("");
  };

  return { name, setName, handleCreate };
};
