import { useGroupHook } from "./useGroupHook";
import "./NewGroupForm.css";

export const NewGroupForm = () => {
  const { name, setName, handleCreate } = useGroupHook();

  return (
    <div className="newGroupForm">
      <input
        className="textInput"
        placeholder="group name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button className="button mainButton smallButton" onClick={handleCreate}>
        create
      </button>
    </div>
  );
};
