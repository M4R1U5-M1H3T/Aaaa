import './TopBar.css';

export const TopBar = () => (
    <header className="topBar">
        <div className="userInfo">
            <span className="statusDot online"></span>
            <span className="userName">You</span>
            <span className="userMeta">listening on port 64894</span>
        </div>
    </header>
);
