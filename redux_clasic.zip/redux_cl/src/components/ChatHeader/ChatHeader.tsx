import "./ChatHeader.css";
import {
  useAppDispatch,
  useAppSelector,
  toggleInvite,
  selectTitle,
  selectIsGroup,
  selectActiveGroup,
} from "../../store";

export const ChatHeader = () => {
  const dispatch = useAppDispatch();
  const title = useAppSelector(selectTitle);
  const showInviteButton = useAppSelector(selectIsGroup);
  const activeGroup = useAppSelector(selectActiveGroup);

  return (
    <div className="chatHeader">
      <div className="chatTitle">{title}</div>
      <div className="chatButtons">
        {showInviteButton && (
          <button
            className="button"
            onClick={() => activeGroup && dispatch(toggleInvite(activeGroup.id))}
          >
            invite
          </button>
        )}
      </div>
    </div>
  );
};
