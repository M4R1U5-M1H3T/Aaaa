import { useInviteHook } from "./useInviteHook";
import { useAppSelector, selectGroupMembers, selectPeopleToInvite } from "../../store";
import "./InviteBox.css";

export const InviteBox = () => {
  const members = useAppSelector(selectGroupMembers);
  const peopleToInvite = useAppSelector(selectPeopleToInvite);
  const { selected, toggle, handleSubmit } = useInviteHook();

  return (
    <div className="inviteBox">
      <div className="inviteLabel">invite to group</div>
      <div className="inviteOptions">
        {peopleToInvite.map((name) => {
          const alreadyMember = members.includes(name);
          return (
            <label key={name}>
              <input
                type="checkbox"
                checked={alreadyMember || selected.includes(name)}
                disabled={alreadyMember}
                onChange={() => toggle(name)}
              />
              {name}
            </label>
          );
        })}
      </div>
      <button className="button mainButton smallButton" onClick={handleSubmit}>
        invite selected
      </button>
    </div>
  );
};
