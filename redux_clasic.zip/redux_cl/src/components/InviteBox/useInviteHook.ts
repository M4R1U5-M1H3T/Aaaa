import { useState } from "react";
import { useAppDispatch, useAppSelector, invite, selectActiveGroup } from "../../store";

export const useInviteHook = () => {
  const dispatch = useAppDispatch();
  const activeGroup = useAppSelector(selectActiveGroup);
  const [selected, setSelected] = useState<string[]>([]);

  const toggle = (name: string) => {
    setSelected((current) =>
      current.includes(name) ? current.filter((n) => n !== name) : [...current, name]
    );
  };

  const handleSubmit = () => {
    if (activeGroup) dispatch(invite(activeGroup.id, selected));
    setSelected([]);
  };

  return { selected, toggle, handleSubmit };
};
