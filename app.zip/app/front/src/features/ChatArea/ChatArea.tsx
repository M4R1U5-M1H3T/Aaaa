import { ChatHeader, InviteBox, MessageList, MessageForm } from "../../components";
import {
  useAppSelector,
  useAppDispatch,
  selectShowInviteBox,
  selectTitle,
  selectIsGroup,
  selectHasOpenChat,
  selectMessages,
  selectGroupMembers,
  selectPeopleToInvite,
  selectSelectedGroupId,
  selectActivePeer,
  selectActiveGroup,
  toggleInvite,
  membersInvited,
  messageAddedToPeer,
  messageAddedToGroup,
} from "../../store";
import "./ChatArea.css";

export const ChatArea = () => {
  const dispatch = useAppDispatch();

  const showInviteBox = useAppSelector(selectShowInviteBox);
  const title = useAppSelector(selectTitle);
  const isGroup = useAppSelector(selectIsGroup);
  const hasOpenChat = useAppSelector(selectHasOpenChat);
  const messages = useAppSelector(selectMessages);
  const groupMembers = useAppSelector(selectGroupMembers);
  const peopleToInvite = useAppSelector(selectPeopleToInvite);
  const selectedGroupId = useAppSelector(selectSelectedGroupId);
  const activePeer = useAppSelector(selectActivePeer);
  const activeGroup = useAppSelector(selectActiveGroup);

  const handleToggleInvite = () => {
    if (selectedGroupId) dispatch(toggleInvite(selectedGroupId));
  };

  const handleInvite = (names: string[]) => {
    if (selectedGroupId) dispatch(membersInvited({ groupId: selectedGroupId, names }));
  };

  const handleSend = (text: string) => {
    const message = { author: "me", text, fromMe: true };
    if (activePeer) dispatch(messageAddedToPeer({ peerId: activePeer.id, message }));
    else if (activeGroup) dispatch(messageAddedToGroup({ groupId: activeGroup.id, message }));
  };

  return (
    <main className="chatArea">
      <ChatHeader title={title} showInviteButton={isGroup} onToggleInvite={handleToggleInvite} />

      {showInviteBox && (
        <InviteBox members={groupMembers} peopleToInvite={peopleToInvite} onInvite={handleInvite} />
      )}

      <div className="messageArea">
        <MessageList messages={messages} hasOpenChat={hasOpenChat} />
      </div>

      <MessageForm onSend={handleSend} />
    </main>
  );
};
