import { PeerList, GroupList, NewGroupForm } from "../../components";
import {
  useAppSelector,
  useAppDispatch,
  selectPeers,
  selectGroups,
  selectSelectedPeerId,
  selectSelectedGroupId,
  openPeer,
  openGroup,
  addGroup,
} from "../../store";
import "./SideBar.css";

export const Sidebar = () => {
  const dispatch = useAppDispatch();

  const peers = useAppSelector(selectPeers);
  const groups = useAppSelector(selectGroups);
  const selectedPeerId = useAppSelector(selectSelectedPeerId);
  const selectedGroupId = useAppSelector(selectSelectedGroupId);

  const handleSelectPeer = (id: string) => dispatch(openPeer(id));
  const handleSelectGroup = (id: string) => dispatch(openGroup(id));

  const handleCreateGroup = (name: string) => {
    const id = `g${Date.now()}`;
    dispatch(addGroup({ id, name, members: [], messages: [] }));
  };

  return (
    <aside className="sidebar">
      <section className="sidebarSection">
        <div className="sidebarTitle">peers</div>
        <PeerList peers={peers} activePeerId={selectedPeerId} onSelect={handleSelectPeer} />
      </section>

      <section className="sidebarSection">
        <div className="sidebarTitle">groups</div>
        <NewGroupForm onCreate={handleCreateGroup} />
        <GroupList groups={groups} activeGroupId={selectedGroupId} onSelect={handleSelectGroup} />
      </section>
    </aside>
  );
};
