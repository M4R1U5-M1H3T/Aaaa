import { useState } from 'react';
import type { Peer } from "../../models";
import { useAppDispatch, useAppSelector, addPeer, setPeerOnline, selectPeers } from "../../store";

export const useConnectHook = () => {
  const dispatch = useAppDispatch();
  const peers = useAppSelector(selectPeers);

  const [host, setHost] = useState("127.0.0.1");
  const [port, setPort] = useState("");

  const handleConnect = () => {
    if (host.trim() === "" || port.trim() === "") return;
    const id = `p${peers.length + 1}`;
    const peer: Peer = { id, name: `${host}:${port}`, online: false, messages: [] };
    dispatch(addPeer(peer));
    window.setTimeout(() => {
      dispatch(setPeerOnline(id));
    }, 700);
  };

  return { host, setHost, port, setPort, handleConnect };
};
