import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import type { RootState } from "./store";
import { selectPeers } from "./peersSlice";
import { selectGroups } from "./groupsSlice";
import type { Peer, Group } from "../models";

export interface UiState {
  selectedPeerId: string | null;
  selectedGroupId: string | null;
  inviteBoxOpenFor: string | null;
  peopleToInvite: string[];
}

const initialState: UiState = {
  selectedPeerId: null,
  selectedGroupId: "g1",
  inviteBoxOpenFor: null,
  peopleToInvite: ["alice", "bob"],
};

const uiSlice = createSlice({
  name: "ui",
  initialState,
  reducers: {
    openPeer: (state, action: PayloadAction<string>) => {
      state.selectedPeerId = action.payload;
      state.selectedGroupId = null;
      state.inviteBoxOpenFor = null;
    },

    openGroup: (state, action: PayloadAction<string>) => {
      state.selectedGroupId = action.payload;
      state.selectedPeerId = null;
      state.inviteBoxOpenFor = null;
    },

    toggleInvite: (state, action: PayloadAction<string>) => {
      state.inviteBoxOpenFor =
        state.inviteBoxOpenFor === action.payload ? null : action.payload;
    },

    closeInvite: (state) => {
      state.inviteBoxOpenFor = null;
    },
  },
});

export const { openPeer, openGroup, toggleInvite, closeInvite } = uiSlice.actions;
export default uiSlice.reducer;

export const selectSelectedPeerId = (state: RootState) => state.ui.selectedPeerId;
export const selectSelectedGroupId = (state: RootState) => state.ui.selectedGroupId;
export const selectInviteBoxOpenFor = (state: RootState) => state.ui.inviteBoxOpenFor;
export const selectPeopleToInvite = (state: RootState) => state.ui.peopleToInvite;

export const selectActivePeer = (state: RootState) =>
  selectPeers(state).find((p: Peer) => p.id === state.ui.selectedPeerId);

export const selectActiveGroup = (state: RootState) =>
  selectGroups(state).find((g: Group) => g.id === state.ui.selectedGroupId);

export const selectHasOpenChat = (state: RootState) =>
  selectActivePeer(state) !== undefined || selectActiveGroup(state) !== undefined;

export const selectIsGroup = (state: RootState) =>
  selectActiveGroup(state) !== undefined;

export const selectTitle = (state: RootState) => {
  const activePeer = selectActivePeer(state);
  const activeGroup = selectActiveGroup(state);
  if (activePeer) return activePeer.name;
  if (activeGroup)
    return `# ${activeGroup.name} (${activeGroup.members.length + 1} members)`;
  return "select a peer or group";
};

export const selectMessages = (state: RootState) => {
  const activePeer = selectActivePeer(state);
  const activeGroup = selectActiveGroup(state);
  return activePeer?.messages ?? activeGroup?.messages ?? [];
};

export const selectGroupMembers = (state: RootState) =>
  selectActiveGroup(state)?.members ?? [];

export const selectShowInviteBox = (state: RootState) => {
  const activeGroup = selectActiveGroup(state);
  return activeGroup !== undefined && state.ui.inviteBoxOpenFor === activeGroup.id;
};
