import { useEffect } from "react";
import { ChatApp, NameGate } from "./features";
import { control } from "./net/controlClient";
import { useAppSelector, selectReady } from "./store";

export const App = () => {
  const ready = useAppSelector(selectReady);

  // Open the control WebSocket to our local backend once, on mount.
  useEffect(() => {
    control.start();
  }, []);

  return ready ? <ChatApp /> : <NameGate />;
};
