import { store } from "../store";
import {
  setConnected,
  setReady,
  setListeningPort,
  logLine,
  inviteReceived,
  peersSnapshot,
  directMessage,
  groupsSnapshot,
  groupMessage,
} from "../store";
import type { ClientCommand, ServerEvent } from "./protocol";

const DEFAULT_URL = "ws://127.0.0.1:8090";

function controlUrl(): string {
  const fromEnv = import.meta.env.VITE_CONTROL_URL as string | undefined;
  return fromEnv && fromEnv.trim() !== "" ? fromEnv : DEFAULT_URL;
}

/**
 * Singleton wrapper around the local control WebSocket. Sends UI commands to the
 * backend bridge and turns backend events into Redux dispatches. Reconnects
 * automatically if the backend is not up yet.
 */
class ControlClient {
  private ws: WebSocket | null = null;
  private url = controlUrl();
  private queue: ClientCommand[] = [];
  private reconnectTimer: number | null = null;
  private started = false;

  /** Open the connection (idempotent). Call once on app start. */
  start(): void {
    if (this.started) return;
    this.started = true;
    this.open();
  }

  private open(): void {
    try {
      this.ws = new WebSocket(this.url);
    } catch {
      this.scheduleReconnect();
      return;
    }

    this.ws.onopen = () => {
      store.dispatch(setConnected(true));
      // Flush anything queued while offline.
      const pending = this.queue;
      this.queue = [];
      for (const cmd of pending) this.rawSend(cmd);
    };

    this.ws.onclose = () => {
      store.dispatch(setConnected(false));
      this.ws = null;
      this.scheduleReconnect();
    };

    this.ws.onerror = () => {
      // onclose will follow and handle reconnect.
    };

    this.ws.onmessage = (ev: MessageEvent) => {
      let parsed: ServerEvent;
      try {
        parsed = JSON.parse(ev.data as string) as ServerEvent;
      } catch {
        return;
      }
      this.handleEvent(parsed);
    };
  }

  private scheduleReconnect(): void {
    if (this.reconnectTimer !== null) return;
    this.reconnectTimer = window.setTimeout(() => {
      this.reconnectTimer = null;
      this.open();
    }, 1000);
  }

  private handleEvent(e: ServerEvent): void {
    switch (e.event) {
      case "ready":
        store.dispatch(setReady({ name: e.name, listeningPort: e.listeningPort ?? null }));
        break;
      case "listening":
        store.dispatch(setListeningPort(e.port));
        break;
      case "peers":
        store.dispatch(peersSnapshot(e.peers));
        break;
      case "peerConnected":
        store.dispatch(logLine(`Connected: ${e.name} (${e.address ?? e.id})`));
        break;
      case "peerDisconnected":
        store.dispatch(logLine(`Disconnected: ${e.id} (${e.reason})`));
        break;
      case "message":
        store.dispatch(
          directMessage({ peerId: e.peerId, author: e.from, text: e.text, fromMe: e.fromMe })
        );
        break;
      case "groupMessage":
        store.dispatch(
          groupMessage({ group: e.group, author: e.from, text: e.text, fromMe: e.fromMe })
        );
        break;
      case "groups":
        store.dispatch(groupsSnapshot(e.groups));
        break;
      case "invite":
        store.dispatch(inviteReceived({ group: e.group, from: e.from }));
        store.dispatch(logLine(`Invite to group ${e.group} from ${e.from}`));
        break;
      case "log":
        store.dispatch(logLine(e.text));
        break;
      case "error":
        store.dispatch(logLine(`Error: ${e.text}`));
        break;
      default:
        break;
    }
  }

  send(cmd: ClientCommand): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.rawSend(cmd);
    } else {
      this.queue.push(cmd);
    }
  }

  private rawSend(cmd: ClientCommand): void {
    this.ws?.send(JSON.stringify(cmd));
  }

  // Convenience wrappers ------------------------------------------------------
  init(name: string, listenPort?: number) {
    this.send({ cmd: "init", name, ...(listenPort ? { listenPort } : {}) });
  }
  connect(host: string, port: number) {
    this.send({ cmd: "connect", host, port });
  }
  listen(port: number) {
    this.send({ cmd: "listen", port });
  }
  closePeer(id: string) {
    this.send({ cmd: "close", id });
  }
  sendDirect(to: string, text: string) {
    this.send({ cmd: "sendDirect", to, text });
  }
  sendGroup(group: string, text: string) {
    this.send({ cmd: "sendGroup", group, text });
  }
  groupCreate(name: string) {
    this.send({ cmd: "groupCreate", name });
  }
  invite(peer: string, group: string) {
    this.send({ cmd: "invite", peer, group });
  }
  accept(group: string) {
    this.send({ cmd: "accept", group });
  }
  reject(group: string) {
    this.send({ cmd: "reject", group });
  }
  leave(group: string) {
    this.send({ cmd: "leave", group });
  }
}

export const control = new ControlClient();
