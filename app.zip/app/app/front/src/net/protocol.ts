// Shared shapes for the local control-WebSocket protocol between the React UI
// and its own Java backend bridge (com.lseg.control.ControlServer).
//
// Commands: UI -> backend. Events: backend -> UI.

export interface PeerSnapshot {
  id: string;
  name: string;
  host?: string | null;
  port?: number | null;
  address?: string;
}

export interface GroupSnapshot {
  name: string;
  members: string[];
}

// ---- Events (backend -> UI) ----
export type ServerEvent =
  | { event: "ready"; name: string; listeningPort?: number }
  | { event: "listening"; port: number }
  | { event: "peerConnected"; id: string; name: string; host?: string | null; port?: number; address?: string }
  | { event: "peerDisconnected"; id: string; reason: string }
  | { event: "peers"; peers: PeerSnapshot[] }
  | { event: "message"; peerId: string; from: string; text: string; fromMe: boolean }
  | { event: "groupMessage"; group: string; from: string; text: string; fromMe: boolean }
  | { event: "groups"; groups: GroupSnapshot[] }
  | { event: "invite"; group: string; from: string }
  | { event: "log"; text: string }
  | { event: "error"; text: string };

// ---- Commands (UI -> backend) ----
export type ClientCommand =
  | { cmd: "init"; name: string; listenPort?: number }
  | { cmd: "connect"; host: string; port: number }
  | { cmd: "listen"; port: number }
  | { cmd: "close"; id: string }
  | { cmd: "listPeers" }
  | { cmd: "listGroups" }
  | { cmd: "sendDirect"; to: string; text: string }
  | { cmd: "sendGroup"; group: string; text: string }
  | { cmd: "groupCreate"; name: string }
  | { cmd: "invite"; peer: string; group: string }
  | { cmd: "accept"; group: string }
  | { cmd: "reject"; group: string }
  | { cmd: "leave"; group: string };
