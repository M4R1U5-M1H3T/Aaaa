import { useState } from "react";

export const useGroupHook = (onCreate: (name: string) => void) => {
  const [name, setName] = useState("");

  const handleCreate = () => {
    onCreate(name);
    setName("");
  };

  return { name, setName, handleCreate };
};
