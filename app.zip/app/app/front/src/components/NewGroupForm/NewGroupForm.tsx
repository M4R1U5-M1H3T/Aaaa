import { useGroupHook } from "./useGroupHook";
import type { NewGroupFormProps } from "../../models";
import "./NewGroupForm.css";

export const NewGroupForm = ({ onCreate }: NewGroupFormProps) => {
  const { name, setName, handleCreate } = useGroupHook(onCreate);

  return (
    <div className="newGroupForm">
      <input
        className="textInput"
        placeholder="group name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button className="button mainButton smallButton" onClick={handleCreate}>
        create
      </button>
    </div>
  );
};
