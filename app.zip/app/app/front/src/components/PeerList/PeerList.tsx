import type { PeerListProps } from "../../models";
import "./PeerList.css";

export const PeerList = ({ peers, activePeerId, onSelect, onClose }: PeerListProps) => {
  if (peers.length === 0) {
    return <div className="emptyText small">no peers yet — connect to one above</div>;
  }
  return (
    <ul className="list">
      {peers.map((peer) => (
        <li
          key={peer.id}
          className={peer.id === activePeerId ? "activeItem" : ""}
          onClick={() => onSelect(peer.id)}
        >
          <span className={`statusDot ${peer.online ? "online" : ""}`}></span>
          <span className="itemName">{peer.name}</span>
          <span className="itemStatus">{peer.online ? "online" : "offline"}</span>
          {onClose && peer.online && (
            <button
              className="closeButton"
              title="disconnect"
              onClick={(e) => {
                e.stopPropagation();
                onClose(peer.id);
              }}
            >
              ×
            </button>
          )}
        </li>
      ))}
    </ul>
  );
};
