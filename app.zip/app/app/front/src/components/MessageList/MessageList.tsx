import type { MessageListProps } from "../../models";
import "./MessageList.css";

export const MessageList = ({ messages, hasOpenChat }: MessageListProps) => {
  return (
    !hasOpenChat ? ( <div className="emptyText">pick a peer or a group to start chatting</div>) 
                 : messages.length === 0 ? ( <div className="emptyText">no messages yet</div>)
                                         : (
                                            <>
                                              {messages.map((message, index) => (
                                                <div key={index} className={`message ${message.fromMe ? "myMessage" : ""}`}>
                                                  <div className="messageAuthor">{message.author}</div>
                                                  <div>{message.text}</div>
                                                </div>
                                              ))}
                                            </>
                                           )
  );
};
