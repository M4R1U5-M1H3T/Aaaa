import type { GroupListProps } from "../../models";
import "./GroupList.css";

export const GroupList = ({ groups, activeGroupId, onSelect }: GroupListProps) => {
  return (
    <ul className="list">
      {groups.map((group) => (
        <li
          key={group.id}
          className={group.id === activeGroupId ? "activeItem" : ""}
          onClick={() => onSelect(group.id)}
        >
          <span className="itemName"># {group.name}</span>
        </li>
      ))}
    </ul>
  );
};
