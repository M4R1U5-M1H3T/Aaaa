import "./ChatHeader.css";
import type { ChatHeaderProps } from "../../models";

export const ChatHeader = ({ title, showInviteButton, onToggleInvite }: ChatHeaderProps) => {
  return (
    <div className="chatHeader">
      <div className="chatTitle">{title}</div>
      <div className="chatButtons">
        {showInviteButton && (
          <button className="button" onClick={onToggleInvite}>
            invite
          </button>
        )}
      </div>
    </div>
  );
};
