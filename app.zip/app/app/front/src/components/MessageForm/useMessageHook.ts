import { useState } from "react";

export const useMessageHook = (onSend: (text: string) => void) => { 

  const [text, setText] = useState("");

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    onSend(text);
    setText("");
  };

  return { text, setText, handleSubmit };
};
