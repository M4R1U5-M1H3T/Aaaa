import { useMessageHook } from "./useMessageHook";
import type { MessageFormProps } from "../../models";
import "./MessageForm.css";

export const MessageForm = ({ onSend }: MessageFormProps) => {
  const { text, setText, handleSubmit } = useMessageHook(onSend);

  return (
    <form className="messageForm" onSubmit={handleSubmit}>
      <input
        className="textInput"
        placeholder="type a message..."
        autoComplete="off"
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button className="button mainButton" type="submit">
        send
      </button>
    </form>
  );
};
