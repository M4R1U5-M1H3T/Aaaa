import { useState } from "react";

export const useInviteHook = (onInvite: (selected: string[]) => void) => {
  const [selected, setSelected] = useState<string[]>([]);

  const toggle = (name: string) => {
    setSelected((current) =>
      current.includes(name) ? current.filter((n) => n !== name) : [...current, name]
    );
  };

  const handleSubmit = () => {
    onInvite(selected);
    setSelected([]);
  };

  return { selected, toggle, handleSubmit };
};
