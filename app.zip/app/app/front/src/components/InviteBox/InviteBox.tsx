import { useInviteHook } from "./useInviteHook";
import type { InviteBoxProps } from "../../models";
import "./InviteBox.css";

export const InviteBox = ({ members, peopleToInvite, onInvite }: InviteBoxProps) => {
  const { selected, toggle, handleSubmit } = useInviteHook(onInvite);

  return (
    <div className="inviteBox">
      <div className="inviteLabel">invite to group</div>
      <div className="inviteOptions">
        {peopleToInvite.map((name) => {
          const alreadyMember = members.includes(name);
          return (
            <label key={name}>
              <input
                type="checkbox"
                checked={alreadyMember || selected.includes(name)}
                disabled={alreadyMember}
                onChange={() => toggle(name)}
              />
              {name}
            </label>
          );
        })}
      </div>
      <button className="button mainButton smallButton" onClick={handleSubmit}>
        invite selected
      </button>
    </div>
  );
};
