import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import type { Peer } from "../models";
import type { PeerSnapshot } from "../net/protocol";
import type { RootState } from "./store";

export type PeersState = Peer[];

const initialState: PeersState = [];

const peersSlice = createSlice({
  name: "peers",
  initialState,
  reducers: {
    // Reconcile against the backend's active-connections snapshot while keeping
    // per-peer message history for peers we have seen before.
    peersSnapshot: (state, action: PayloadAction<PeerSnapshot[]>) => {
      const seen = new Set<string>();
      for (const incoming of action.payload) {
        seen.add(incoming.id);
        const existing = state.find((p) => p.id === incoming.id);
        if (existing) {
          existing.name = incoming.name;
          existing.host = incoming.host ?? null;
          existing.port = incoming.port ?? null;
          existing.online = true;
        } else {
          state.push({
            id: incoming.id,
            name: incoming.name,
            host: incoming.host ?? null,
            port: incoming.port ?? null,
            online: true,
            messages: [],
          });
        }
      }
      // Peers no longer in the snapshot are offline, but keep their history.
      for (const p of state) {
        if (!seen.has(p.id)) p.online = false;
      }
    },

    directMessage: (
      state,
      action: PayloadAction<{ peerId: string; author: string; text: string; fromMe: boolean }>
    ) => {
      const { peerId, author, text, fromMe } = action.payload;
      const peer = state.find((p) => p.id === peerId);
      if (peer) peer.messages.push({ author, text, fromMe });
    },

    peersReset: () => [],
  },
});

export const { peersSnapshot, directMessage, peersReset } = peersSlice.actions;
export default peersSlice.reducer;

export const selectPeers = (state: RootState) => state.peers;
export const selectPeerById = (state: RootState, peerId: string) =>
  state.peers.find((p: Peer) => p.id === peerId);
