import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import type { RootState } from "./store";
import { selectPeers } from "./peersSlice";
import { selectGroups } from "./groupsSlice";
import type { Peer, Group } from "../models";

export interface PendingInvite {
  group: string;
  from: string;
}

export interface UiState {
  name: string | null;          // our own name (null until init)
  listeningPort: number | null; // our peer listening port
  connected: boolean;           // control WS connected to backend
  ready: boolean;               // backend acknowledged init

  selectedPeerId: string | null;
  selectedGroupName: string | null;
  inviteBoxOpen: boolean;

  invites: PendingInvite[];
  log: string[];
}

const MAX_LOG = 200;

const initialState: UiState = {
  name: null,
  listeningPort: null,
  connected: false,
  ready: false,
  selectedPeerId: null,
  selectedGroupName: null,
  inviteBoxOpen: false,
  invites: [],
  log: [],
};

const uiSlice = createSlice({
  name: "ui",
  initialState,
  reducers: {
    setConnected: (state, action: PayloadAction<boolean>) => {
      state.connected = action.payload;
    },

    setReady: (
      state,
      action: PayloadAction<{ name: string; listeningPort: number | null }>
    ) => {
      state.name = action.payload.name;
      state.listeningPort = action.payload.listeningPort;
      state.ready = true;
    },

    setListeningPort: (state, action: PayloadAction<number>) => {
      state.listeningPort = action.payload;
    },

    openPeer: (state, action: PayloadAction<string>) => {
      state.selectedPeerId = action.payload;
      state.selectedGroupName = null;
      state.inviteBoxOpen = false;
    },

    openGroup: (state, action: PayloadAction<string>) => {
      state.selectedGroupName = action.payload;
      state.selectedPeerId = null;
      state.inviteBoxOpen = false;
    },

    toggleInvite: (state) => {
      state.inviteBoxOpen = !state.inviteBoxOpen;
    },

    closeInvite: (state) => {
      state.inviteBoxOpen = false;
    },

    inviteReceived: (state, action: PayloadAction<PendingInvite>) => {
      const exists = state.invites.some(
        (i) => i.group === action.payload.group && i.from === action.payload.from
      );
      if (!exists) state.invites.push(action.payload);
    },

    inviteResolved: (state, action: PayloadAction<string>) => {
      state.invites = state.invites.filter((i) => i.group !== action.payload);
    },

    logLine: (state, action: PayloadAction<string>) => {
      state.log.push(action.payload);
      if (state.log.length > MAX_LOG) state.log.splice(0, state.log.length - MAX_LOG);
    },
  },
});

export const {
  setConnected,
  setReady,
  setListeningPort,
  openPeer,
  openGroup,
  toggleInvite,
  closeInvite,
  inviteReceived,
  inviteResolved,
  logLine,
} = uiSlice.actions;
export default uiSlice.reducer;

// ---- basic selectors ----
export const selectName = (state: RootState) => state.ui.name;
export const selectListeningPort = (state: RootState) => state.ui.listeningPort;
export const selectConnected = (state: RootState) => state.ui.connected;
export const selectReady = (state: RootState) => state.ui.ready;
export const selectSelectedPeerId = (state: RootState) => state.ui.selectedPeerId;
export const selectSelectedGroupName = (state: RootState) => state.ui.selectedGroupName;
export const selectInviteBoxOpen = (state: RootState) => state.ui.inviteBoxOpen;
export const selectInvites = (state: RootState) => state.ui.invites;
export const selectLog = (state: RootState) => state.ui.log;

// ---- derived selectors ----
export const selectActivePeer = (state: RootState): Peer | undefined =>
  selectPeers(state).find((p: Peer) => p.id === state.ui.selectedPeerId);

export const selectActiveGroup = (state: RootState): Group | undefined =>
  selectGroups(state).find((g: Group) => g.name === state.ui.selectedGroupName);

export const selectHasOpenChat = (state: RootState) =>
  selectActivePeer(state) !== undefined || selectActiveGroup(state) !== undefined;

export const selectIsGroup = (state: RootState) => selectActiveGroup(state) !== undefined;

export const selectTitle = (state: RootState) => {
  const activePeer = selectActivePeer(state);
  const activeGroup = selectActiveGroup(state);
  if (activePeer) return activePeer.name;
  if (activeGroup) return `# ${activeGroup.name} (${activeGroup.members.length} members)`;
  return "select a peer or group";
};

export const selectMessages = (state: RootState) => {
  const activePeer = selectActivePeer(state);
  const activeGroup = selectActiveGroup(state);
  return activePeer?.messages ?? activeGroup?.messages ?? [];
};

export const selectGroupMembers = (state: RootState) =>
  selectActiveGroup(state)?.members ?? [];

// Connected peers that can be invited to the active group (by name).
export const selectInvitablePeerNames = (state: RootState) =>
  selectPeers(state)
    .filter((p: Peer) => p.online)
    .map((p: Peer) => p.name);

export const selectShowInviteBox = (state: RootState) =>
  selectActiveGroup(state) !== undefined && state.ui.inviteBoxOpen;
