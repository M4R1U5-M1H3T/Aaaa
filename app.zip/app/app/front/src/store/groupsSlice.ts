import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import type { Group } from "../models";
import type { GroupSnapshot } from "../net/protocol";
import type { RootState } from "./store";

export type GroupsState = Group[];

const initialState: GroupsState = [];

const groupsSlice = createSlice({
  name: "groups",
  initialState,
  reducers: {
    // Replace the group list from a backend snapshot, preserving message
    // history for groups that still exist. Groups we left simply drop out.
    groupsSnapshot: (state, action: PayloadAction<GroupSnapshot[]>): GroupsState =>
      action.payload.map((g) => {
        const existing = state.find((x) => x.name === g.name);
        return {
          id: g.name,
          name: g.name,
          members: g.members,
          messages: existing ? existing.messages : [],
        };
      }),

    groupMessage: (
      state,
      action: PayloadAction<{ group: string; author: string; text: string; fromMe: boolean }>
    ) => {
      const { group, author, text, fromMe } = action.payload;
      let g = state.find((x) => x.name === group);
      if (!g) {
        g = { id: group, name: group, members: [], messages: [] };
        state.push(g);
      }
      g.messages.push({ author, text, fromMe });
    },

    groupsReset: () => [],
  },
});

export const { groupsSnapshot, groupMessage, groupsReset } = groupsSlice.actions;
export default groupsSlice.reducer;

export const selectGroups = (state: RootState) => state.groups;
export const selectGroupByName = (state: RootState, name: string) =>
  state.groups.find((g: Group) => g.name === name);
