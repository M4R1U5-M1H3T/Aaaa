import { useState } from "react";
import { control } from "../../net/controlClient";
import { useAppSelector, selectConnected } from "../../store";
import "./NameGate.css";

export const NameGate = () => {
  const connected = useAppSelector(selectConnected);
  const [name, setName] = useState("");
  const [port, setPort] = useState("");

  const handleStart = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = name.trim();
    if (trimmed === "") return;
    const listenPort = port.trim() === "" ? undefined : Number(port.trim());
    control.init(trimmed, Number.isNaN(listenPort as number) ? undefined : listenPort);
  };

  return (
    <div className="nameGate">
      <form className="nameCard" onSubmit={handleStart}>
        <h1 className="nameTitle">peer chat</h1>
        <p className="nameSubtitle">
          {connected
            ? "connected to backend — pick a name to start"
            : "waiting for the local backend bridge…"}
        </p>
        <input
          className="textInput"
          placeholder="your name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          autoFocus
        />
        <input
          className="textInput"
          placeholder="listen port (optional)"
          value={port}
          onChange={(e) => setPort(e.target.value)}
        />
        <button className="button mainButton" type="submit" disabled={!connected}>
          start
        </button>
        <span className={`statusLine ${connected ? "ok" : ""}`}>
          {connected ? "● backend online" : "○ backend offline"}
        </span>
      </form>
    </div>
  );
};
