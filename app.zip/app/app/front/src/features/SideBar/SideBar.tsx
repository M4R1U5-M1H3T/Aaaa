import { PeerList, GroupList, NewGroupForm } from "../../components";
import {
  useAppSelector,
  useAppDispatch,
  selectPeers,
  selectGroups,
  selectInvites,
  selectSelectedPeerId,
  selectSelectedGroupName,
  openPeer,
  openGroup,
  inviteResolved,
} from "../../store";
import { control } from "../../net/controlClient";
import "./SideBar.css";

export const Sidebar = () => {
  const dispatch = useAppDispatch();

  const peers = useAppSelector(selectPeers);
  const groups = useAppSelector(selectGroups);
  const invites = useAppSelector(selectInvites);
  const selectedPeerId = useAppSelector(selectSelectedPeerId);
  const selectedGroupName = useAppSelector(selectSelectedGroupName);

  const handleSelectPeer = (id: string) => dispatch(openPeer(id));
  const handleSelectGroup = (name: string) => dispatch(openGroup(name));
  const handleClosePeer = (id: string) => control.closePeer(id);

  const handleCreateGroup = (name: string) => {
    if (name.trim() !== "") control.groupCreate(name.trim());
  };

  const handleAccept = (group: string) => {
    control.accept(group);
    dispatch(inviteResolved(group));
  };
  const handleReject = (group: string) => {
    control.reject(group);
    dispatch(inviteResolved(group));
  };

  return (
    <aside className="sidebar">
      {invites.length > 0 && (
        <section className="sidebarSection">
          <div className="sidebarTitle">invites</div>
          <ul className="list">
            {invites.map((inv) => (
              <li key={`${inv.group}:${inv.from}`} className="inviteRow">
                <span className="itemName">
                  # {inv.group} <span className="itemStatus">from {inv.from}</span>
                </span>
                <span className="inviteActions">
                  <button className="button smallButton" onClick={() => handleAccept(inv.group)}>
                    accept
                  </button>
                  <button className="button smallButton" onClick={() => handleReject(inv.group)}>
                    reject
                  </button>
                </span>
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="sidebarSection">
        <div className="sidebarTitle">peers</div>
        <PeerList
          peers={peers}
          activePeerId={selectedPeerId}
          onSelect={handleSelectPeer}
          onClose={handleClosePeer}
        />
      </section>

      <section className="sidebarSection">
        <div className="sidebarTitle">groups</div>
        <NewGroupForm onCreate={handleCreateGroup} />
        <GroupList groups={groups} activeGroupId={selectedGroupName} onSelect={handleSelectGroup} />
      </section>
    </aside>
  );
};
