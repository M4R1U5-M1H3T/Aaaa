import { useState } from "react";
import {
  useAppSelector,
  selectName,
  selectListeningPort,
  selectConnected,
} from "../../store";
import { control } from "../../net/controlClient";
import "./TopBar.css";

export const TopBar = () => {
  const name = useAppSelector(selectName);
  const port = useAppSelector(selectListeningPort);
  const connected = useAppSelector(selectConnected);

  const [listenPort, setListenPort] = useState("");

  const handleListen = () => {
    const p = Number(listenPort.trim());
    if (listenPort.trim() === "" || Number.isNaN(p)) return;
    control.listen(p);
    setListenPort("");
  };

  return (
    <header className="topBar">
      <div className="userInfo">
        <span className={`statusDot ${connected ? "online" : ""}`}></span>
        <span className="userName">{name ?? "You"}</span>
        <span className="userMeta">
          {port != null ? `listening on port ${port}` : "not listening"}
          {connected ? "" : " · backend offline"}
        </span>
      </div>
      <div className="listenControl">
        <input
          className="textInput smallInput"
          placeholder="re-listen port"
          value={listenPort}
          onChange={(e) => setListenPort(e.target.value)}
        />
        <button className="button" onClick={handleListen}>
          listen
        </button>
      </div>
    </header>
  );
};
