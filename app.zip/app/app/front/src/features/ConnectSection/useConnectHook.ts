import { useState } from "react";
import { control } from "../../net/controlClient";

export const useConnectHook = () => {
  const [host, setHost] = useState("127.0.0.1");
  const [port, setPort] = useState("");

  const handleConnect = () => {
    const h = host.trim();
    const p = Number(port.trim());
    if (h === "" || port.trim() === "" || Number.isNaN(p)) return;
    control.connect(h, p);
    setPort("");
  };

  return { host, setHost, port, setPort, handleConnect };
};
