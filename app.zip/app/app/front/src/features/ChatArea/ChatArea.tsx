import { ChatHeader, InviteBox, MessageList, MessageForm } from "../../components";
import {
  useAppSelector,
  useAppDispatch,
  selectShowInviteBox,
  selectTitle,
  selectIsGroup,
  selectHasOpenChat,
  selectMessages,
  selectGroupMembers,
  selectInvitablePeerNames,
  selectActivePeer,
  selectActiveGroup,
  toggleInvite,
  closeInvite,
} from "../../store";
import { control } from "../../net/controlClient";
import "./ChatArea.css";

export const ChatArea = () => {
  const dispatch = useAppDispatch();

  const showInviteBox = useAppSelector(selectShowInviteBox);
  const title = useAppSelector(selectTitle);
  const isGroup = useAppSelector(selectIsGroup);
  const hasOpenChat = useAppSelector(selectHasOpenChat);
  const messages = useAppSelector(selectMessages);
  const groupMembers = useAppSelector(selectGroupMembers);
  const invitablePeers = useAppSelector(selectInvitablePeerNames);
  const activePeer = useAppSelector(selectActivePeer);
  const activeGroup = useAppSelector(selectActiveGroup);

  const handleToggleInvite = () => dispatch(toggleInvite());

  const handleInvite = (names: string[]) => {
    if (!activeGroup) return;
    for (const name of names) control.invite(name, activeGroup.name);
    dispatch(closeInvite());
  };

  const handleSend = (text: string) => {
    if (text.trim() === "") return;
    if (activePeer) control.sendDirect(activePeer.id, text);
    else if (activeGroup) control.sendGroup(activeGroup.name, text);
  };

  return (
    <main className="chatArea">
      <ChatHeader title={title} showInviteButton={isGroup} onToggleInvite={handleToggleInvite} />

      {showInviteBox && (
        <InviteBox members={groupMembers} peopleToInvite={invitablePeers} onInvite={handleInvite} />
      )}

      <div className="messageArea">
        <MessageList messages={messages} hasOpenChat={hasOpenChat} />
      </div>

      <MessageForm onSend={handleSend} />
    </main>
  );
};
