export interface ChatHeaderProps {
  title: string;
  showInviteButton: boolean;
  onToggleInvite: () => void;
};
