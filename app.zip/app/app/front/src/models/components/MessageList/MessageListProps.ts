import type { ChatMessage } from "../../../models";

export interface MessageListProps {
  messages: ChatMessage[];
  hasOpenChat: boolean;
};
