export interface MessageFormProps {
  onSend: (text: string) => void;
};
