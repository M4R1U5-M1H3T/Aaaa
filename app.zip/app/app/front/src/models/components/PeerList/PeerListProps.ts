import type { Peer } from "../../../models";

export interface PeerListProps {
  peers: Peer[];
  activePeerId: string | null;
  onSelect: (id: string) => void;
  onClose?: (id: string) => void;
};
