import type { Group } from "../../../models";

export interface GroupListProps {
  groups: Group[];
  activeGroupId: string | null;
  onSelect: (id: string) => void;
};
