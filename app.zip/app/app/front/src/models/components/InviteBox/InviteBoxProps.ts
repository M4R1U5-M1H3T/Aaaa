export interface InviteBoxProps {
  members: string[];
  peopleToInvite: string[];
  onInvite: (names: string[]) => void;
};
