export interface NewGroupFormProps {
  onCreate: (name: string) => void;
}
