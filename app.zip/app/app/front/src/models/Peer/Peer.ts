import type { ChatMessage } from '../ChatMessage';

export interface Peer {
  id: string;            // backend connection id (e.g. "c1")
  name: string;          // remote peer name (falls back to id until handshake known)
  host?: string | null;  // remote host, when known
  port?: number | null;  // remote listening port, when known
  online: boolean;       // present in the latest active-connections snapshot
  messages: ChatMessage[];
}
