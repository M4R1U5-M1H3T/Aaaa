import type { ChatMessage } from '../ChatMessage';

export interface Group {
  id: string;         // equals name; kept for stable React keys / selection
  name: string;
  members: string[];  // member names (excludes you on the wire; you are implicit)
  messages: ChatMessage[];
}
