package com.lseg.control;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.lseg.group.GroupManager;
import com.lseg.network.Connection;
import com.lseg.network.ConnectionListener;
import com.lseg.network.ConnectionManager;
import com.lseg.protocol.Message;
import com.lseg.protocol.MessageType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

/**
 * Bridges the React UI to the exact same peer-to-peer engine the CLI uses.
 *
 * <p>This class does NOT change any peer-to-peer logic: it holds a
 * {@link ConnectionManager} and a {@link GroupManager} constructed exactly like
 * {@code com.lseg.ui.Ui} does, translates JSON commands coming from the UI into
 * the same manager calls the CLI makes, and pushes structured JSON events back
 * so the UI can mirror what the CLI prints.
 */
public class UiController {
    private static final Logger log = LogManager.getLogger(UiController.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private final Consumer<String> sink;

    private volatile String localName;
    private volatile ConnectionManager manager;
    private volatile GroupManager groupManager;

    /**
     * @param sink receives serialized JSON event strings to be delivered to every connected UI client
     */
    public UiController(Consumer<String> sink) {
        this.sink = sink;
    }

    // ---------------------------------------------------------------- incoming commands

    /** Handle one JSON command line from a UI client. */
    public void handleCommand(String raw) {
        JsonNode node;
        try {
            node = MAPPER.readTree(raw);
        } catch (Exception e) {
            emitError("Malformed command: " + e.getMessage());
            return;
        }
        String cmd = text(node, "cmd");
        if (cmd == null) {
            emitError("Missing 'cmd' field");
            return;
        }
        try {
            dispatch(cmd, node);
        } catch (Exception e) {
            emitError("Error running '" + cmd + "': " + e.getMessage());
            log.error("Command failed: {}", raw, e);
        }
    }

    private void dispatch(String cmd, JsonNode node) {
        switch (cmd) {
            case "init" -> doInit(text(node, "name"), intOrNull(node, "listenPort"));
            case "connect" -> doConnect(text(node, "host"), intOrNull(node, "port"));
            case "listen" -> doListen(intOrNull(node, "port"));
            case "close" -> doClose(text(node, "id"));
            case "listPeers" -> emitPeers();
            case "listGroups" -> emitGroups();
            case "sendDirect" -> doSendDirect(text(node, "to"), text(node, "text"));
            case "sendGroup" -> doSendGroup(text(node, "group"), text(node, "text"));
            case "groupCreate" -> doGroupCreate(text(node, "name"));
            case "invite" -> doInvite(text(node, "peer"), text(node, "group"));
            case "accept" -> doAccept(text(node, "group"));
            case "reject" -> doReject(text(node, "group"));
            case "leave" -> doLeave(text(node, "group"));
            default -> emitError("Unknown command: " + cmd);
        }
    }

    private boolean ensureReady() {
        if (manager == null || groupManager == null) {
            emitError("Not initialized yet. Send an 'init' command with your name first.");
            return false;
        }
        return true;
    }

    private void doInit(String name, Integer listenPort) {
        if (name == null || name.isBlank()) {
            emitError("init requires a non-empty 'name'");
            return;
        }
        if (manager != null) {
            // Already initialized; just re-announce current state.
            emitReady();
            emitPeers();
            emitGroups();
            return;
        }
        this.localName = name.trim();
        this.manager = new ConnectionManager(localName, new ConnectionListener() {
            @Override
            public void onConnected(Connection connection) {
                emitPeerConnected(connection);
            }

            @Override
            public void onMessage(Connection connection, Message message) {
                onPeerMessage(connection, message);
            }

            @Override
            public void onDisconnected(Connection connection, String reason) {
                emitPeerDisconnected(connection, reason);
            }
        });
        this.groupManager = new GroupManager(localName, manager, this::emitLog);

        try {
            manager.startListening();
            emitLog("Listening on port " + manager.getListeningPort() + " as " + localName);
        } catch (IOException e) {
            emitLog("Could not start listening automatically!");
            log.warn("Automatic listening failed.", e);
        }
        emitReady();
        emitPeers();
        emitGroups();
    }

    private void doConnect(String host, Integer port) {
        if (!ensureReady()) {
            return;
        }
        if (host == null || host.isBlank() || port == null) {
            emitError("connect requires 'host' and 'port'");
            return;
        }
        try {
            manager.connectTo(host.trim(), port);
            // onConnected event fires from the manager callback.
        } catch (IOException e) {
            emitError("Could not connect: " + e.getMessage());
            log.warn("connectTo {}:{} failed", host, port, e);
        }
    }

    private void doListen(Integer port) {
        if (!ensureReady()) {
            return;
        }
        if (port == null) {
            emitError("listen requires 'port'");
            return;
        }
        try {
            manager.startListening(port);
            emitLog("Listening on port " + port + " as " + localName);
            emitReady();
        } catch (IOException e) {
            emitError("Could not start listening: " + e.getMessage());
            log.warn("startListening failed on port {}", port, e);
        }
    }

    private void doClose(String id) {
        if (!ensureReady()) {
            return;
        }
        if (id == null || id.isBlank()) {
            emitError("close requires 'id'");
            return;
        }
        manager.close(id.trim());
    }

    private void doSendDirect(String to, String textBody) {
        if (!ensureReady()) {
            return;
        }
        if (to == null || to.isBlank() || textBody == null || textBody.isEmpty()) {
            emitError("sendDirect requires 'to' and 'text'");
            return;
        }
        // Same resolution order as the CLI: by remote name, then by connection id.
        Connection connection = manager.getByRemoteName(to.trim());
        if (connection == null) {
            connection = manager.get(to.trim());
        }
        if (connection == null) {
            emitError("No connected peer '" + to + "'.");
            return;
        }
        connection.send(Message.chat(localName, textBody));
        emitDirectMessage(connection.getId(), localName, textBody, true);
    }

    private void doSendGroup(String group, String textBody) {
        if (!ensureReady()) {
            return;
        }
        if (group == null || group.isBlank() || textBody == null || textBody.isEmpty()) {
            emitError("sendGroup requires 'group' and 'text'");
            return;
        }
        groupManager.send(group.trim(), textBody);
        emitGroupMessage(group.trim(), localName, textBody, true);
    }

    private void doGroupCreate(String name) {
        if (!ensureReady()) {
            return;
        }
        groupManager.createGroup(name == null ? null : name.trim());
        emitGroups();
    }

    private void doInvite(String peer, String group) {
        if (!ensureReady()) {
            return;
        }
        if (peer == null || peer.isBlank() || group == null || group.isBlank()) {
            emitError("invite requires 'peer' and 'group'");
            return;
        }
        groupManager.invite(peer.trim(), group.trim());
    }

    private void doAccept(String group) {
        if (!ensureReady()) {
            return;
        }
        groupManager.accept(group == null ? "" : group.trim());
        emitPeers();
        emitGroups();
    }

    private void doReject(String group) {
        if (!ensureReady()) {
            return;
        }
        groupManager.reject(group == null ? "" : group.trim());
        emitGroups();
    }

    private void doLeave(String group) {
        if (!ensureReady()) {
            return;
        }
        groupManager.leave(group == null ? "" : group.trim());
        emitGroups();
    }

    // ---------------------------------------------------------------- peer callbacks

    private void onPeerMessage(Connection connection, Message message) {
        boolean handled = groupManager.handleIncoming(connection, message);
        if (handled) {
            MessageType type = message.getType();
            if (type == MessageType.GROUP_MSG && groupManager.isMemberOf(message.getGroup())) {
                emitGroupMessage(message.getGroup(), message.getName(), message.getContent(), false);
            } else if (type == MessageType.INVITE) {
                emitInvite(message.getGroup(), message.getName());
            }
            emitGroups();
            return;
        }
        // Not a group message -> direct chat, same as Ui.messageHelper fallback.
        String from = connection.getRemoteName() != null ? connection.getRemoteName() : connection.getId();
        emitDirectMessage(connection.getId(), from, message.getContent(), false);
    }

    // ---------------------------------------------------------------- events out

    private void emitReady() {
        ObjectNode ev = event("ready");
        ev.put("name", localName);
        Integer port = manager != null ? manager.getListeningPort() : null;
        if (port != null) {
            ev.put("listeningPort", port);
        }
        send(ev);
    }

    private void emitPeerConnected(Connection connection) {
        ObjectNode ev = event("peerConnected");
        putPeer(ev, connection);
        send(ev);
        emitPeers();
    }

    private void emitPeerDisconnected(Connection connection, String reason) {
        ObjectNode ev = event("peerDisconnected");
        ev.put("id", connection.getId());
        ev.put("reason", reason);
        send(ev);
        emitPeers();
    }

    private void emitPeers() {
        if (manager == null) {
            return;
        }
        ObjectNode ev = event("peers");
        ArrayNode arr = ev.putArray("peers");
        Collection<Connection> connections = manager.activeConnections();
        for (Connection c : connections) {
            ObjectNode p = arr.addObject();
            putPeer(p, c);
        }
        send(ev);
    }

    private void putPeer(ObjectNode node, Connection c) {
        node.put("id", c.getId());
        node.put("name", c.getRemoteName() != null ? c.getRemoteName() : c.getId());
        node.put("host", c.getRemoteHost());
        if (c.getRemoteListenPort() != null) {
            node.put("port", c.getRemoteListenPort());
        }
        node.put("address", c.getRemoteAddress());
    }

    private void emitDirectMessage(String peerId, String from, String textBody, boolean fromMe) {
        ObjectNode ev = event("message");
        ev.put("peerId", peerId);
        ev.put("from", from);
        ev.put("text", textBody);
        ev.put("fromMe", fromMe);
        send(ev);
    }

    private void emitGroupMessage(String group, String from, String textBody, boolean fromMe) {
        ObjectNode ev = event("groupMessage");
        ev.put("group", group);
        ev.put("from", from);
        ev.put("text", textBody);
        ev.put("fromMe", fromMe);
        send(ev);
    }

    private void emitInvite(String group, String from) {
        ObjectNode ev = event("invite");
        ev.put("group", group);
        ev.put("from", from);
        send(ev);
    }

    private void emitGroups() {
        if (groupManager == null) {
            return;
        }
        ObjectNode ev = event("groups");
        ArrayNode arr = ev.putArray("groups");
        Map<String, List<String>> snapshot = groupManager.groupsSnapshot();
        for (Map.Entry<String, List<String>> entry : snapshot.entrySet()) {
            ObjectNode g = arr.addObject();
            g.put("name", entry.getKey());
            ArrayNode members = g.putArray("members");
            for (String m : entry.getValue()) {
                members.add(m);
            }
        }
        send(ev);
    }

    private void emitLog(String textBody) {
        ObjectNode ev = event("log");
        ev.put("text", textBody);
        send(ev);
    }

    private void emitError(String textBody) {
        ObjectNode ev = event("error");
        ev.put("text", textBody);
        send(ev);
    }

    // ---------------------------------------------------------------- helpers

    private ObjectNode event(String type) {
        ObjectNode node = MAPPER.createObjectNode();
        node.put("event", type);
        return node;
    }

    private void send(ObjectNode node) {
        try {
            sink.accept(MAPPER.writeValueAsString(node));
        } catch (Exception e) {
            log.warn("Failed to serialize event {}", node, e);
        }
    }

    /** Send the current full state to a freshly connected UI client. */
    public void sendSnapshot() {
        if (manager != null) {
            emitReady();
            emitPeers();
            emitGroups();
        }
    }

    public void shutdown() {
        if (manager != null) {
            manager.close();
        }
    }

    private static String text(JsonNode node, String field) {
        JsonNode v = node.get(field);
        return (v == null || v.isNull()) ? null : v.asText();
    }

    private static Integer intOrNull(JsonNode node, String field) {
        JsonNode v = node.get(field);
        if (v == null || v.isNull()) {
            return null;
        }
        if (v.isNumber()) {
            return v.asInt();
        }
        try {
            return Integer.parseInt(v.asText().trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
