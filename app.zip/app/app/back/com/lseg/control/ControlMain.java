package com.lseg.control;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.net.InetSocketAddress;

/**
 * Entry point for running the backend as a UI bridge instead of the interactive
 * CLI. It starts the local control WebSocket that the React frontend connects
 * to. The peer-to-peer engine is unchanged and is driven entirely through the
 * control socket.
 *
 * <p>Control port resolution order: first CLI arg, then CONTROL_PORT env var,
 * then default 8090. Run a second app on the same machine with a different port,
 * e.g. {@code java com.lseg.control.ControlMain 8091}.
 */
public class ControlMain {
    private static final Logger log = LogManager.getLogger(ControlMain.class);
    private static final int DEFAULT_PORT = 8090;

    public static void main(String[] args) {
        int port = resolvePort(args);
        // Bind to loopback only: this control channel is meant for the local UI, not the network.
        ControlServer server = new ControlServer(new InetSocketAddress("127.0.0.1", port));
        server.start();
        System.out.println("Control bridge listening on ws://127.0.0.1:" + port);
        System.out.println("Point the React UI at it (VITE_CONTROL_URL=ws://127.0.0.1:" + port + ").");

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            log.info("Shutting down control bridge");
            server.shutdown();
        }));

        // Keep the JVM alive; the server runs on its own threads.
        try {
            Thread.currentThread().join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    private static int resolvePort(String[] args) {
        if (args.length > 0) {
            try {
                return Integer.parseInt(args[0].trim());
            } catch (NumberFormatException e) {
                log.warn("Invalid port arg '{}', falling back", args[0]);
            }
        }
        String env = System.getenv("CONTROL_PORT");
        if (env != null && !env.isBlank()) {
            try {
                return Integer.parseInt(env.trim());
            } catch (NumberFormatException e) {
                log.warn("Invalid CONTROL_PORT '{}', falling back", env);
            }
        }
        return DEFAULT_PORT;
    }
}
