package com.lseg.control;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

import java.net.InetSocketAddress;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Local-only control WebSocket that the React UI connects to. It is completely
 * separate from the peer-to-peer {@code PeerServer}: peers never talk to this
 * socket. It simply forwards UI commands to a single {@link UiController} and
 * broadcasts the controller's events to every connected UI client.
 */
public class ControlServer extends WebSocketServer {
    private static final Logger log = LogManager.getLogger(ControlServer.class);

    private final Set<WebSocket> clients = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private final UiController controller;

    public ControlServer(InetSocketAddress address) {
        super(address);
        setReuseAddr(true);
        this.controller = new UiController(this::broadcast);
    }

    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {
        clients.add(conn);
        log.info("UI client connected: {}", conn.getRemoteSocketAddress());
        // Bring a freshly (re)connected UI up to date with current state.
        controller.sendSnapshot();
    }

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        clients.remove(conn);
        log.info("UI client disconnected: {} ({})", conn.getRemoteSocketAddress(), reason);
    }

    @Override
    public void onMessage(WebSocket conn, String message) {
        controller.handleCommand(message);
    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        log.warn("Control socket error: {}", ex.getMessage());
    }

    @Override
    public void onStart() {
        log.info("Control server listening on {}", getAddress());
    }

    private void broadcast(String json) {
        for (WebSocket client : clients) {
            try {
                if (client.isOpen()) {
                    client.send(json);
                }
            } catch (Exception e) {
                log.debug("Failed to push event to UI client: {}", e.getMessage());
            }
        }
    }

    public void shutdown() {
        controller.shutdown();
        try {
            stop(500);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
