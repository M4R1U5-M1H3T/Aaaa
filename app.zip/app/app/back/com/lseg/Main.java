package com.lseg;

import com.lseg.ui.Ui;

import java.io.IOException;

public class Main {
    static void main() throws IOException {
        IO.println("What is your name?");
        String name = IO.readln();

        Ui ui = new Ui(name);
        ui.start();
    }
}
