package com.lseg.group;

import com.lseg.network.Connection;
import com.lseg.network.ConnectionManager;
import com.lseg.protocol.Message;
import com.lseg.protocol.MemberInfo;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public class GroupManager {
    private static final Logger log = LogManager.getLogger(GroupManager.class);

    private final String localName;
    private final ConnectionManager manager;
    private final Consumer<String> out;

    private final Map<String, Group> groups = new ConcurrentHashMap<>();
    private final Map<String, PendingInvite> pendingInvites = new ConcurrentHashMap<>();

    public GroupManager(String localName, ConnectionManager manager, Consumer<String> out) {
        this.localName = localName;
        this.manager = manager;
        this.out = out;
    }

    private record PendingInvite(String groupName, String inviterName, List<MemberInfo> members) {
    }


    public void createGroup(String groupName) {
        if (groupName == null || groupName.isBlank()) {
            out.accept("Usage: group create <name>");
            return;
        }
        if (groups.containsKey(groupName)) {
            out.accept("Group " + groupName + " already exists.");
            return;
        }
        Group group = new Group(groupName);
        group.addMember(localName);
        groups.put(groupName, group);
        out.accept("Created group " + groupName + ". Invite peers with: invite <name> " + groupName);
    }

    public void invite(String peerName, String groupName) {
        Group group = groups.get(groupName);
        if (group == null) {
            out.accept("You are not in a group called " + groupName + ".");
            return;
        }
        Connection peer = manager.getByRemoteName(peerName);
        if (peer == null) {
            out.accept("Not connected to a peer named " + peerName + ". Connect to them first.");
            return;
        }
        if (group.hasMember(peerName)) {
            out.accept(peerName + " is already in group " + groupName + ".");
            return;
        }
        peer.send(Message.invite(localName, groupName, buildMemberList(group)));
        out.accept("Invited " + peerName + " to group " + groupName + ".");
    }

    public void accept(String groupName) {
        PendingInvite invite = pendingInvites.remove(groupName);
        if (invite == null) {
            out.accept("No pending invite for group " + groupName + ".");
            return;
        }

        Group group = new Group(groupName);
        for (MemberInfo m : invite.members()) {
            group.addMember(m.getName());
        }
        group.addMember(localName);
        groups.put(groupName, group);

        connectToAdvertisedMembers(groupName, invite.members());

        sendTo(invite.inviterName(), Message.inviteAccept(localName, groupName));
        out.accept("Joined group " + groupName + ". Members: " + group.getMembers());
    }

    public void reject(String groupName) {
        PendingInvite invite = pendingInvites.remove(groupName);
        if (invite == null) {
            out.accept("No pending invite for group " + groupName + ".");
            return;
        }
        sendTo(invite.inviterName(), Message.inviteReject(localName, groupName));
        out.accept("Rejected invite to group " + groupName + ".");
    }

    public void send(String groupName, String text) {
        Group group = groups.get(groupName);
        if (group == null) {
            out.accept("You are not in a group called " + groupName + ".");
            return;
        }
        Message msg = Message.groupMessage(localName, groupName, text);
        for (String member : group.getMembers()) {
            if (member.equals(localName)) {
                continue;
            }
            if (!sendTo(member, msg)) {
                out.accept("(could not deliver to " + member + ")");
            }
        }
        out.accept("[" + groupName + "] you: " + text);
    }

    public void leave(String groupName) {
        Group group = groups.remove(groupName);
        if (group == null) {
            out.accept("You are not in a group called " + groupName + ".");
            return;
        }
        Message msg = Message.groupLeave(localName, groupName);
        for (String member : group.getMembers()) {
            if (!member.equals(localName)) {
                sendTo(member, msg);
            }
        }
        out.accept("Left group " + groupName + ".");
    }

    public void listGroups() {
        if (groups.isEmpty()) {
            out.accept("You are not in any groups.");
            return;
        }
        out.accept("Groups:");
        for (Group g : groups.values()) {
            out.accept("  " + g.getName() + " -> " + g.getMembers());
        }
    }


    /**
     * Read-only snapshot of current groups and their members. Used by the UI
     * bridge to render group state. Does not alter any peer-to-peer behaviour.
     */
    public Map<String, List<String>> groupsSnapshot() {
        Map<String, List<String>> snapshot = new LinkedHashMap<>();
        for (Group g : groups.values()) {
            snapshot.put(g.getName(), new ArrayList<>(g.getMembers()));
        }
        return snapshot;
    }

    public boolean isMemberOf(String groupName) {
        return groups.containsKey(groupName);
    }

    public boolean handleIncoming(Connection from, Message msg) {
        switch (msg.getType()) {
            case INVITE -> onInvite(msg);
            case INVITE_ACCEPT -> onInviteAccept(msg);
            case INVITE_REJECT -> out.accept(msg.getName() + " rejected the invite to group " + msg.getGroup() + ".");
            case GROUP_JOIN -> onGroupJoin(msg);
            case GROUP_MSG -> onGroupMessage(msg);
            case GROUP_LEAVE -> onGroupLeave(msg);
            default -> {
                return false;
            }
        }
        log.debug("Handled {} from {}", msg.getType(), from.getRemoteName());
        return true;
    }

    private void onInvite(Message msg) {
        String group = msg.getGroup();
        List<MemberInfo> members = msg.getMembers() != null ? msg.getMembers() : List.of();
        pendingInvites.put(group, new PendingInvite(group, msg.getName(), members));
        out.accept("*** Invite to group " + group + " from " + msg.getName()
                + ". Type accept " + group + " or reject " + group + ".");
    }

    private void onInviteAccept(Message msg) {
        String group = msg.getGroup();
        String newMember = msg.getName();
        Group g = groups.get(group);
        if (g == null) {
            log.warn("Got INVITE_ACCEPT for a group I don't own: {}", group);
            return;
        }
        g.addMember(newMember);
        out.accept(newMember + " joined group " + group + ".");
        broadcastMembers(g, newMember);
    }

    private void onGroupJoin(Message msg) {
        String group = msg.getGroup();
        String newMember = msg.getName();
        Group g = groups.get(group);
        if (g == null) {
            log.warn("Got GROUP_JOIN for unknown group: {}", group);
            return;
        }
        boolean addedNewMember = false;
        List<MemberInfo> members = msg.getMembers() != null ? msg.getMembers() : List.of();
        for (MemberInfo member : members) {
            if (!g.hasMember(member.getName())) {
                g.addMember(member.getName());
                if (member.getName().equals(newMember)) {
                    addedNewMember = true;
                }
            }
        }
        if (!g.hasMember(newMember)) {
            g.addMember(newMember);
            addedNewMember = true;
        }
        if (addedNewMember) {
            out.accept(newMember + " joined group " + group + ".");
        }
        connectToAdvertisedMembers(group, members);
        if (addedNewMember) {
            broadcastMembers(g, newMember);
        }
    }

    private void onGroupMessage(Message msg) {
        String group = msg.getGroup();
        if (!groups.containsKey(group)) {
            log.debug("Ignoring group message for a group I'm not in: {}", group);
            return;
        }
        out.accept("[" + group + "] " + msg.getName() + ": " + msg.getContent());
    }

    private void onGroupLeave(Message msg) {
        String group = msg.getGroup();
        String leaver = msg.getName();
        Group g = groups.get(group);
        if (g != null) {
            g.removeMember(leaver);
            out.accept(leaver + " left group " + group + ".");
        }
    }


    private List<MemberInfo> buildMemberList(Group group) {
        List<MemberInfo> infos = new ArrayList<>();
        for (String member : group.getMembers()) {
            if (member.equals(localName)) {
                infos.add(new MemberInfo(localName, "127.0.0.1", manager.getListeningPort()));
                continue;
            }
            Connection c = manager.getByRemoteName(member);
            if (c != null) {
                infos.add(new MemberInfo(member, c.getRemoteHost(), c.getRemoteListenPort()));
            } else {
                infos.add(new MemberInfo(member, null, null));
            }
        }
        return infos;
    }

    private void connectToAdvertisedMembers(String groupName, List<MemberInfo> members) {
        for (MemberInfo m : members) {
            if (m.getName().equals(localName)) {
                continue;
            }
            if (manager.getByRemoteName(m.getName()) != null) {
                continue;
            }
            if (!m.isReachable()) {
                out.accept("Cannot reach member " + m.getName() + " (no address advertised); skipping.");
                log.warn("Group {} join: member {} has no reachable address", groupName, m);
                continue;
            }
            if (localName.compareTo(m.getName()) >= 0) {
                continue;
            }
            try {
                manager.connectTo(m.getHost(), m.getPort());
                // IO.println(localName + " connected to " + m.getName()); // debug msg to see who connected to whom
            } catch (IOException e) {
                out.accept("Could not connect to member " + m.getName() + ": " + e.getMessage());
                log.warn("Group {} join: connect to {} failed", groupName, m, e);
            }
        }
    }

    private void broadcastMembers(Group g, String announcedMember) {
        Message join = Message.groupJoin(announcedMember, g.getName(), buildMemberList(g));
        for (String member : g.getMembers()) {
            if (member.equals(localName)) {
                continue;
            }
            if (!sendTo(member, join)) {
                log.warn("Could not gossip membership update to {} for group {}", member, g.getName());
            }
        }
    }

    private boolean sendTo(String memberName, Message msg) {
        Connection c = manager.getByRemoteName(memberName);
        if (c == null) {
            log.warn("No connection to member {} to deliver {}", memberName, msg.getType());
            return false;
        }
        c.send(msg);
        return true;
    }
}