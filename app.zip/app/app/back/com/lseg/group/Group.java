package com.lseg.group;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class Group {
    private final String name;
    private final Set<String> members = ConcurrentHashMap.newKeySet();

    public Group(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public Set<String> getMembers() {
        return members;
    }

    public void addMember(String memberName) {
        members.add(memberName);
    }

    public void removeMember(String memberName) {
        members.remove(memberName);
    }

    public boolean hasMember(String memberName) {
        return members.contains(memberName);
    }
}
