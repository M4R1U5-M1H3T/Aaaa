package com.lseg.protocol;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class MemberInfo {
    private final String name;
    private final String host;
    private final Integer port;

    @JsonCreator
    public MemberInfo(
            @JsonProperty("name") String name,
            @JsonProperty("host") String host,
            @JsonProperty("port") Integer port
    ) {
        this.name = name;
        this.host = host;
        this.port = port;
    }

    public String getName() {
        return name;
    }

    public String getHost() {
        return host;
    }

    public Integer getPort() {
        return port;
    }

    @JsonIgnore
    public boolean isReachable() {
        return host != null && port != null && port > 0;
    }

    @Override
    public String toString() {
        return name + "@" + host + ":" + port;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof MemberInfo that)) {
            return false;
        }
        return Objects.equals(name, that.name)
                && Objects.equals(host, that.host)
                && Objects.equals(port, that.port);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, host, port);
    }
}
