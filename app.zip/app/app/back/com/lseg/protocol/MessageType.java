package com.lseg.protocol;

public enum MessageType {
    HELLO,
    ACK,
    MSG,
    BYE,

    INVITE,
    INVITE_ACCEPT,
    INVITE_REJECT,
    GROUP_JOIN,
    GROUP_MSG,
    GROUP_LEAVE
}
