package com.lseg.protocol;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lseg.exceptions.JsonDeserializationException;
import com.lseg.exceptions.JsonSerializationException;

import java.util.List;
import java.util.Objects;

public class Message {
    private final MessageType type;
    private final String name;
    private final String content;
    private final Integer port;
    private final String group;
    private final List<MemberInfo> members;

    private static final ObjectMapper objectMapper = new ObjectMapper();

    @JsonCreator
    public Message(
            @JsonProperty("type") MessageType type,
            @JsonProperty("name") String name,
            @JsonProperty("content") String content,
            @JsonProperty("port") Integer port,
            @JsonProperty("group") String group,
            @JsonProperty("members") List<MemberInfo> members
    ) {
        this.type = type;
        this.name = name;
        this.content = content;
        this.port = port;
        this.group = group;
        this.members = members;
    }

    public static Message hello(String name, Integer listenPort) {
        return new Message(MessageType.HELLO, name, null, listenPort, null, null);
    }

    public static Message ack(String name, Integer listenPort) {
        return new Message(MessageType.ACK, name, null, listenPort, null, null);
    }

    public static Message chat(String senderName, String content) {
        return new Message(MessageType.MSG, senderName, content, null, null, null);
    }

    public static Message bye() {
        return new Message(MessageType.BYE, null, null, null, null, null);
    }


    public static Message invite(String senderName, String group, List<MemberInfo> members) {
        return new Message(MessageType.INVITE, senderName, null, null, group, members);
    }

    public static Message inviteAccept(String senderName, String group) {
        return new Message(MessageType.INVITE_ACCEPT, senderName, null, null, group, null);
    }

    public static Message inviteReject(String senderName, String group) {
        return new Message(MessageType.INVITE_REJECT, senderName, null, null, group, null);
    }

    public static Message groupJoin(String newMemberName, String group, List<MemberInfo> members) {
        return new Message(MessageType.GROUP_JOIN, newMemberName, null, null, group, members);
    }

    public static Message groupMessage(String senderName, String group, String content) {
        return new Message(MessageType.GROUP_MSG, senderName, content, null, group, null);
    }

    public static Message groupLeave(String senderName, String group) {
        return new Message(MessageType.GROUP_LEAVE, senderName, null, null, group, null);
    }



    public MessageType getType() {
        return this.type;
    }

    public String getName() {
        return this.name;
    }

    public String getContent() {
        return this.content;
    }

    public Integer getPort() {
        return this.port;
    }

    public String getGroup() {
        return this.group;
    }

    public List<MemberInfo> getMembers() {
        return this.members;
    }

    public String toJson() {
        try {
            return objectMapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            throw new JsonSerializationException("Failed to serialize message of type " + this.type, e);
        }
    }

    public static Message fromJson(String line) {
        try {
            return objectMapper.readValue(line, Message.class);
        } catch (JsonProcessingException e) {
            throw new JsonDeserializationException("Invalid message: " + line, e);
        }
    }

    @Override
    public String toString() {
        return "Message{type=" + type + ", name=" + name + ", content=" + content
                + ", port=" + port + ", group=" + group + ", members=" + members + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Message that)) {
            return false;
        }
        return this.type == that.type
                && Objects.equals(this.name, that.name)
                && Objects.equals(this.content, that.content)
                && Objects.equals(this.port, that.port)
                && Objects.equals(this.group, that.group)
                && Objects.equals(this.members, that.members);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.type, this.name, this.content, this.port, this.group, this.members);
    }
}
