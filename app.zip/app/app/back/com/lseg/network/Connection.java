package com.lseg.network;

import com.lseg.exceptions.JsonParsingException;
import com.lseg.exceptions.JsonSerializationException;
import com.lseg.protocol.Message;
import com.lseg.protocol.MessageType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.java_websocket.WebSocket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

public class Connection {
    private static final Logger log = LogManager.getLogger(Connection.class);

    public final String id;
    private final WebSocket ws;
    private final CompletableFuture<Message> handshakeFuture = new CompletableFuture<>();
    private final AtomicBoolean closed = new AtomicBoolean(false);

    public volatile String remoteName;
    public volatile Integer remoteListenPort;
    private volatile ConnectionListener handler;

    public Connection(String id, WebSocket ws) {
        this.id = id;
        this.ws = ws;
    }

    void start(ConnectionListener handler) {
        this.handler = handler;
    }

    public String getId() {
        return this.id;
    }

    public String getRemoteName() {
        return this.remoteName;
    }

    public Integer getRemoteListenPort() {
        return this.remoteListenPort;
    }

    void completeHandshake(String remoteName, Integer remoteListenPort) {
        this.remoteName = remoteName;
        this.remoteListenPort = remoteListenPort;
    }

    public InetSocketAddress getRemoteSocketAddress() {
        return ws.getRemoteSocketAddress();
    }

    public String getRemoteAddress() {
        InetSocketAddress addr = getRemoteSocketAddress();
        return addr != null ? addr.toString() : "unknown";
    }

    public String getRemoteHost() {
        InetSocketAddress addr = getRemoteSocketAddress();
        return (addr != null && addr.getAddress() != null) ? addr.getAddress().getHostAddress() : null;
    }

    boolean isRegistered() {
        return handler != null;
    }

    public void send(Message message) {
        if (closed.get()) {
            return;
        }
        String json;
        try {
            json = message.toJson();
        } catch (JsonSerializationException e) {
            log.error("Dropping un-serializable outgoing message on {}", describe(), e);
            return;
        }
        try {
            ws.send(json);
        } catch (Exception e) {
            log.debug("Send failed on {}: {}", describe(), e.getMessage());
            close("send error: " + e.getMessage());
        }
    }

    void onMessageReceived(String raw) {
        Message message;
        try {
            message = Message.fromJson(raw);
        } catch (JsonParsingException e) {
            log.warn("Ignoring malformed message from {}: {}", describe(), e.getMessage());
            return;
        }
        if (message.getType() == MessageType.BYE) {
            close("peer sent BYE");
            return;
        }
        if (this.handler == null) {
            handshakeFuture.complete(message);
            return;
        }
        this.handler.onMessage(this, message);
    }

    Message waitForHandshakeReply(long timeoutMs) throws IOException {
        try {
            return handshakeFuture.get(timeoutMs, TimeUnit.MILLISECONDS);
        }catch (TimeoutException e){
            throw new IOException("Handshake timed out on " + id);
        }catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted during handshake on " + id, e);
        }catch (ExecutionException e) {
            throw new IOException("Handshake failed on " + id, e.getCause());
        }
    }

    private String describe() {
        return id + (remoteName != null ? " (" + remoteName + ")" : "");
    }

    void close(String reason) {
        if (!closed.compareAndSet(false, true)) {
            return;
        }
        log.debug("Closing {}: {}", describe(), reason);
        try {
            ws.close();
        } catch (Exception e) {
            log.debug("Error closing connection for {}: {}", describe(), e.getMessage());
        }
        ConnectionListener h = this.handler;
        if (h != null) {
            h.onDisconnected(this, reason);
        }
    }

    void disconnect() {
        if (!closed.get()) {
            try {
                ws.send(Message.bye().toJson());
            } catch (JsonSerializationException e) {
                log.debug("Could not serialize BYE for {}: {}", describe(), e.getMessage());
            } catch (Exception e) {
                log.debug("Could not send BYE for {}: {}", describe(), e.getMessage());
            }
            close("closed locally");
        }
    }
}