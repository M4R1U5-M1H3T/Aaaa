package com.lseg.network;

import com.lseg.exceptions.PeerServerException;
import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

import java.net.InetSocketAddress;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

public class PeerServer extends WebSocketServer {
    private static final int CONNECT_TIMEOUT_MS = 5000;

    private final CountDownLatch started = new CountDownLatch(1);
    private final AtomicReference<Exception> bindingFailure = new AtomicReference<>();
    private final ConnectionManager manager;

    public PeerServer(InetSocketAddress address, ConnectionManager manager) {
        super(address);
        this.manager = manager;
        setReuseAddr(true);
    }

    @Override
    public void start() {
        super.start();
        try {
            if (!started.await(CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                throw new PeerServerException("Timed out starting WebSocket server");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new PeerServerException("Interrupted while starting server");
        }
        if (bindingFailure.get() != null) {
            throw new PeerServerException("Port is not available (already in use?)");
        }
    }

    @Override
    public void onStart() {
        if (started != null) {
            started.countDown();
        }
    }

    @Override
    public void onOpen(WebSocket conn, ClientHandshake __) {
        manager.onServerOpen(conn);
    }

    @Override
    public void onMessage(WebSocket conn, String message) {
        manager.onServerMessage(conn, message);
    }

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        manager.onServerClose(conn, reason);
    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        if (conn == null) {
            if (bindingFailure != null) {
                bindingFailure.set(ex);
            }
            if (started != null) {
                started.countDown();
            }
            return;
        }
        manager.onServerConnectionError(conn, ex);
    }
}