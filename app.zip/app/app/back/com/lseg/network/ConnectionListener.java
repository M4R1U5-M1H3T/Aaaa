package com.lseg.network;

import com.lseg.protocol.Message;

public interface ConnectionListener {
    void onConnected(Connection connection);

    void onMessage(Connection connection, Message message);

    void onDisconnected(Connection connection, String reason);
}
