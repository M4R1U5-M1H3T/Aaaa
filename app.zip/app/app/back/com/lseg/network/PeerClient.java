package com.lseg.network;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;

public class PeerClient extends WebSocketClient {
    final Connection connection;
    private final ConnectionManager manager;

    public PeerClient(URI serverUri, String id, ConnectionManager manager) {
        super(serverUri);
        this.manager = manager;
        this.connection = new Connection(id, this);
    }

    @Override
    public void onOpen(ServerHandshake __) {
        manager.onClientOpen(this);
    }

    @Override
    public void onMessage(String message) {
        connection.onMessageReceived(message);
    }

    @Override
    public void onClose(int code, String reason, boolean remote) {
        manager.onClientClose(this, reason);
    }

    @Override
    public void onError(Exception ex) {
        manager.onClientError(this, ex);
    }
}