package com.lseg.network;

import com.lseg.exceptions.JsonParsingException;
import com.lseg.exceptions.PeerServerException;
import com.lseg.protocol.Message;
import com.lseg.protocol.MessageType;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.java_websocket.WebSocket;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class ConnectionManager implements AutoCloseable {
    private static final Logger log = LogManager.getLogger(ConnectionManager.class);

    private static final int CONNECT_TIMEOUT_MS = 5000;

    private final String localName;

    private final ConnectionListener appListener;
    private final ConnectionListener managedListener;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private final Map<String, Connection> connections = new ConcurrentHashMap<>();
    private final Map<WebSocket, Connection> connectionByWebSocket = new ConcurrentHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);

    private volatile PeerServer server;
    private volatile Integer listeningPort;

    public ConnectionManager(String localName, ConnectionListener appListener) {
        this.localName = localName;
        this.appListener = appListener;
        this.managedListener = new ManagedConnectionListener(appListener, connections);
    }

    public void startListening() throws IOException {
        startListening(0);
    }

    public void startListening(int port) throws IOException {
        if (server != null && listeningPort != null && port != 0 && listeningPort == port) {
            log.info("Already listening on port {}", port);
            return;
        }
        if (server != null) {
            log.info("Switching listen port {} -> {}", listeningPort, port == 0 ? "<random>" : port);
            stopListening();
        }

        PeerServer newServer = new PeerServer(new InetSocketAddress(port), this);
        try {
            newServer.start();
        } catch (PeerServerException e) {
            throw new IOException(e);
        }
        server = newServer;
        listeningPort = newServer.getPort();
        log.info("Listening on port {} as {}", listeningPort, localName);
    }

    private void stopListening() {
        PeerServer s = server;
        server = null;
        listeningPort = null;
        if (s != null) {
            try {
                s.stop(500);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                log.debug("Interrupted while stopping server");
            }
        }
    }

    public Connection connectTo(String host, int port) throws IOException {
        String id = "c" + nextId.getAndIncrement();
        URI uri;
        try {
            uri = new URI("ws://" + host + ":" + port);
        } catch (URISyntaxException e) {
            throw new IOException("Invalid address: " + host + ":" + port, e);
        }

        PeerClient client = new PeerClient(uri, id, this);
        connectionByWebSocket.put(client, client.connection);

        connectClient(host, port, client);
        checkAndSetConnection(client);

        replaceExistingConnectionTo(client.connection);
        register(client.connection);
        return client.connection;
    }

    private void connectClient(String host, int port, PeerClient client) throws IOException {
        boolean opened;
        try {
            opened = client.connectBlocking(CONNECT_TIMEOUT_MS, TimeUnit.MILLISECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            connectionByWebSocket.remove(client);
            throw new IOException("Interrupted while connecting to " + host + ":" + port, e);
        }
        if (!opened) {
            connectionByWebSocket.remove(client);
            throw new IOException("Connection to " + host + ":" + port + " failed (refused or unreachable)");
        }
    }

    private void checkAndSetConnection(PeerClient client) throws IOException {
        Message first;
        try {
            first = client.connection.waitForHandshakeReply(CONNECT_TIMEOUT_MS);
        } catch (IOException e) {
            client.connection.close("handshake failed: " + e.getMessage());
            connectionByWebSocket.remove(client);
            throw e;
        }
        if (first.getType() != MessageType.ACK) {
            client.connection.close("expected ACK, got " + first.getType());
            connectionByWebSocket.remove(client);
            throw new IOException("Handshake rejected by peer: expected ACK, got " + first.getType());
        }
        client.connection.completeHandshake(first.getName(), first.getPort());
    }

    private void replaceExistingConnectionTo(Connection fresh) {
        InetSocketAddress target = fresh.getRemoteSocketAddress();
        if (target == null) {
            return;
        }
        for (Connection existing : connections.values()) {
            if (existing == fresh) {
                continue;
            }
            if (target.equals(existing.getRemoteSocketAddress())) {
                log.info("Replacing existing connection {} to {}", existing.getId(), target);
                existing.disconnect();
            }
        }
    }

    private void register(Connection connection) {
        connections.put(connection.getId(), connection);
        connection.start(managedListener);
        pool.submit(() -> appListener.onConnected(connection));
    }

    public Collection<Connection> activeConnections() {
        return connections.values();
    }

    public Connection get(String id) {
        return connections.get(id);
    }

    public Integer getListeningPort() {
        return listeningPort;
    }

    public Connection getByRemoteName(String name) {
        if (name == null) {
            return null;
        }
        for (Connection connection : connections.values()) {
            if (name.equalsIgnoreCase(connection.getRemoteName())) {
                return connection;
            }
        }
        return null;
    }

    public void close(String id) {
        Connection connection = connections.get(id);
        if (connection != null) {
            connection.disconnect();
        }
    }

    public void closeAll() {
        stopListening();
        for (Connection connection : connections.values()) {
            connection.disconnect();
        }
    }

    @Override
    public void close() {
        closeAll();
        pool.shutdown();
    }


    void onServerOpen(WebSocket newWebSocket) {
        String id = "c" + nextId.getAndIncrement();
        connectionByWebSocket.put(newWebSocket, new Connection(id, newWebSocket));
    }

    void onServerMessage(WebSocket webSocket, String message) {
        Connection connection = connectionByWebSocket.get(webSocket);
        if (connection == null) {
            webSocket.close();
            return;
        }
        if (connection.isRegistered()) {
            connection.onMessageReceived(message);
            return;
        }
        Message first;
        try {
            first = Message.fromJson(message);
        } catch (JsonParsingException e) {
            log.warn("Rejecting incoming connection {}: bad handshake JSON: {}", connection.getId(), e.getMessage());
            connectionByWebSocket.remove(webSocket);
            webSocket.close();
            return;
        }
        if (first.getType() != MessageType.HELLO) {
            log.warn("Rejecting incoming connection {}: expected HELLO, got {}", connection.getId(), first.getType());
            connectionByWebSocket.remove(webSocket);
            webSocket.close();
            return;
        }
        connection.completeHandshake(first.getName(), first.getPort());
        webSocket.send(Message.ack(localName, listeningPort).toJson());
        register(connection);
    }

    void onServerClose(WebSocket conn, String reason) {
        Connection connection = connectionByWebSocket.remove(conn);
        if (connection != null) {
            connection.close("peer closed: " + reason);
        }
    }

    void onServerConnectionError(WebSocket conn, Exception ex) {
        log.debug("Connection error on {}: {}", conn.getRemoteSocketAddress(), ex.getMessage());
    }


    void onClientOpen(PeerClient client) {
        client.send(Message.hello(localName, listeningPort).toJson());
    }

    void onClientClose(PeerClient client, String reason) {
        connectionByWebSocket.remove(client);
        client.connection.close("peer closed: " + reason);
    }

    void onClientError(PeerClient client, Exception ex) {
        log.debug("Client connection error: {}", ex.getMessage());
    }
}