package com.lseg.network;

import com.lseg.protocol.Message;

import java.util.Map;

public class ManagedConnectionListener implements ConnectionListener{
    private final ConnectionListener appListener;
    private final Map<String, Connection> connections;

    public ManagedConnectionListener(ConnectionListener appListener, Map<String, Connection> connections) {
        this.appListener = appListener;
        this.connections = connections;
    }

    @Override
    public void onConnected(Connection connection) {
        appListener.onConnected(connection);
    }

    @Override
    public void onMessage(Connection connection, Message message) {
        appListener.onMessage(connection, message);
    }

    @Override
    public void onDisconnected(Connection connection, String reason) {
        connections.remove(connection.getId());
        appListener.onDisconnected(connection, reason);
    }
}
