package com.lseg.ui;

import com.lseg.group.GroupManager;
import com.lseg.network.Connection;
import com.lseg.network.ConnectionListener;
import com.lseg.network.ConnectionManager;
import com.lseg.protocol.Message;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicReference;

public class Ui {
    private static final Logger log = LogManager.getLogger(Ui.class);
    private static final String DIRECT_PREFIX = "to_";
    private static final String GROUP_PREFIX = "@";

    private final String localName;
    private final ConnectionManager manager;
    private final GroupManager groupManager;
    private final AtomicReference<String> activeId = new AtomicReference<>();

    public Ui(String localName) {
        this.localName = localName;
        this.manager = new ConnectionManager(localName, new ConnectionListener() {
            @Override
            public void onConnected(Connection connection) {
                connectHelper(connection);
            }

            @Override
            public void onMessage(Connection connection, Message message) {
                messageHelper(connection, message);
            }

            @Override
            public void onDisconnected(Connection connection, String reason) {
                disconnectHelper(connection, reason);
            }
        });
        this.groupManager = new GroupManager(localName, manager, IO::println);
    }

    private void connectHelper(Connection connection) {
        activeId.set(connection.getId());
        IO.println("Connected: " + connection.getId() + " " + details(connection));
    }

    private void messageHelper(Connection connection, Message message) {
        if (groupManager.handleIncoming(connection, message)) {
            return;
        }
        String from = connection.getRemoteName() != null ? connection.getRemoteName() : connection.getId();
        IO.println(from + ": " + message.getContent());
    }

    private void disconnectHelper(Connection connection, String reason) {
        IO.println("Disconnected: " + connection.getId() + "(" + reason + ")");
        activeId.compareAndSet(connection.getId(), null);
    }

    private void printMenu() {
        IO.println("Select one of the available commands!");
        IO.println("1. Start to accept incoming connections");
        IO.println("        listen <port>");
        IO.println("2. Open a new outgoing connection");
        IO.println("        connect <host> <port>");
        IO.println("3. List available connections");
        IO.println("        list");
        IO.println("4. Close one connection");
        IO.println("        close <id>");
        IO.println("5. Close all connections and exit");
        IO.println("        exit");
        IO.println("6. Send a message to an active conversation");
        IO.println("        <message> (only when exactly one peer is connected)");
        IO.println("        to_<name> <message> (send to a specific peer by name)");
        IO.println("7. Group chat");
        IO.println("        group create <name> (start a new group you own)");
        IO.println("        invite <name> <group> (invite a connected peer)");
        IO.println("        accept <group> (accept a pending invite)");
        IO.println("        reject <group> (decline a pending invite)");
        IO.println("        @<group> <message> (send to everyone in the group)");
        IO.println("        groups (list your groups and members)");
        IO.println("        leave <group> (leave a group)");
        IO.println("8. List all available commands");
        IO.println("        help");
    }

    private void commandParse(String line) {
        String[] parts = line.split("\\s+", 2);
        String command = parts[0];
        String args = parts.length > 1 ? parts[1] : "";

        switch (command) {
            case "listen" -> doListen(args.trim());
            case "connect" -> doConnect(args.trim());
            case "list" -> printConnections();
            case "close" -> manager.close(args.trim());
            case "help" -> printMenu();
            case "group" -> doGroup(args.trim());
            case "invite" -> doInvite(args.trim());
            case "accept" -> groupManager.accept(args.trim());
            case "reject" -> groupManager.reject(args.trim());
            case "groups" -> groupManager.listGroups();
            case "leave" -> groupManager.leave(args.trim());
            default -> sendMessage(line);
        }
    }

    private void doGroup(String args) {
        String[] parts = args.split("\\s+", 2);
        String sub = parts[0];
        String rest = parts.length > 1 ? parts[1].trim() : "";
        if ("create".equals(sub)) {
            groupManager.createGroup(rest);
        } else if ("list".equals(sub)) {
            groupManager.listGroups();
        } else {
            IO.println("Usage: group create <name>  |  group list");
        }
    }

    private void doInvite(String args) {
        String[] parts = args.split("\\s+");
        if (parts.length < 2) {
            IO.println("Usage: invite <peer-name> <group>");
            return;
        }
        groupManager.invite(parts[0], parts[1]);
    }

    private void doListen(String portText) {
        int port;
        try {
            port = Integer.parseInt(portText);
        } catch (NumberFormatException e) {
            IO.println("Invalid port: " + portText + ". Usage: listen <port>");
            return;
        }
        try {
            manager.startListening(port);
            IO.println("Listening on port " + port + " as " + localName);
        } catch (IOException e) {
            IO.println("Could not start listening: " + e.getMessage());
            log.warn("startListening failed on port {}", port, e);
        }
    }

    private void doConnect(String args) {
        String[] hostPort = args.split("\\s+");
        if (hostPort.length < 2) {
            IO.println("Usage: connect <host> <port>");
            return;
        }
        int port;
        try {
            port = Integer.parseInt(hostPort[1]);
        } catch (NumberFormatException e) {
            IO.println("Invalid port: " + hostPort[1] + ". Usage: connect <host> <port>");
            return;
        }
        try {
            Connection connection = manager.connectTo(hostPort[0], port);
            // IO.println(localName + " connected to " + connection.getRemoteName()); // debug msg to see who connected to whom
            activeId.set(connection.getId());
        } catch (IOException e) {
            IO.println("Could not connect: " + e.getMessage());
            log.warn("connectTo {}:{} failed", hostPort[0], port, e);
        }
    }

    private void sendMessage(String line) {
        if (line.startsWith(GROUP_PREFIX)) {
            sendGroup(line);
            return;
        }

        Collection<Connection> connections = manager.activeConnections();
        if (connections.isEmpty()) {
            IO.println("No active connections!");
            return;
        }

        if (line.startsWith(DIRECT_PREFIX)) {
            sendDirected(line);
            return;
        }

        if (connections.size() == 1) {
            connections.iterator().next().send(Message.chat(localName, line));
        } else {
            IO.println("Multiple peers connected - address one with: to_<name> <message>");
            printConnections();
        }
    }

    private void sendDirected(String line) {
        String[] parts = line.split("\\s+", 2);
        String target = parts[0].substring(DIRECT_PREFIX.length());
        String body = parts.length > 1 ? parts[1] : "";

        if (target.isEmpty() || body.isEmpty()) {
            IO.println("Usage: to_<name> <message>");
            return;
        }

        Connection connection = manager.getByRemoteName(target);
        if (connection == null) {
            connection = manager.get(target);
        }
        if (connection == null) {
            IO.println("No connected peer with id " + target + ".");
            printConnections();
            return;
        }
        connection.send(Message.chat(localName, body));
    }

    private void sendGroup(String line) {
        String[] parts = line.split("\\s+", 2);
        String group = parts[0].substring(GROUP_PREFIX.length());
        String body = parts.length > 1 ? parts[1] : "";
        if (group.isEmpty() || body.isEmpty()) {
            IO.println("Usage: @<group> <message>");
            return;
        }
        groupManager.send(group, body);
    }

    private void printConnections() {
        var connections = manager.activeConnections();
        if (connections.isEmpty()) {
            IO.println("No active connections!");
        }
        for (Connection connection : connections) {
            String marker = connection.getId().equals(activeId.get()) ? "*" : " ";
            IO.println(marker + " " + connection.getId() + " " + details(connection));
        }
    }

    private static String details(Connection connection) {
        String name = connection.getRemoteName() != null ? connection.getRemoteName() : "?";
        return name + " - " + connection.getRemoteAddress();
    }

    public void start() throws IOException {
        IO.println("Welcome!");
        try {
            manager.startListening();
            IO.println("Listening on port " + manager.getListeningPort() + " as " + localName);
        } catch (IOException e) {
            IO.println("Could not start listening automatically!");
            log.warn("Automatic listening failed.", e);
        }
        printMenu();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(System.in))) {
            String line;
            while ((line = in.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) {
                    continue;
                }
                if (line.equals("exit")) {
                    break;
                }
                try {
                    commandParse(line);
                } catch (Exception e) {
                    IO.println("Error: " + e.getMessage());
                    log.error("Unexpected error handling command: {}", line, e);
                }
            }
        } finally {
            manager.close();
            IO.println("Exiting...");
        }
    }

}
