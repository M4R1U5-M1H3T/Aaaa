package com.lseg.exceptions;

public class JsonSerializationException extends JsonParsingException {
    public JsonSerializationException(String message, Throwable cause) {
        super(message, cause);
    }
}
