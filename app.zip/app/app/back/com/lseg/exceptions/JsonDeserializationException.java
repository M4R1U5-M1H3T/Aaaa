package com.lseg.exceptions;

public class JsonDeserializationException extends JsonParsingException{
    public JsonDeserializationException(String message, Throwable cause) {
        super(message, cause);
    }
}
