package com.lseg.exceptions;

public class PeerServerException extends RuntimeException {
    public PeerServerException(String message) {
        super(message);
    }
}
