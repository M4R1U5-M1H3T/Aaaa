# Wiring the React UI to the peer‑to‑peer backend

This document explains how the new React frontend is connected to the existing
Java backend, and how to run two apps that talk to each other peer‑to‑peer.

## The key idea

A browser **cannot** open a listening socket or accept incoming TCP/WebSocket
connections — it can only be a WebSocket *client*. Your Java backend, on the
other hand, is a real peer: it runs a `PeerServer` (accepts incoming peers) and
a `PeerClient` (dials out), plus all the group invite/gossip logic. So React
cannot be a peer by itself.

Therefore **each app = Java backend (the peer engine) + React UI**, wired like
this:

```
App A:  [React UI] ⇄ localhost control‑WS ⇄ [Java backend] ⇄──── P2P ────┐
                                                                          │
App B:  [React UI] ⇄ localhost control‑WS ⇄ [Java backend] ⇄──── P2P ────┘
```

- The **peer‑to‑peer logic is unchanged.** The two Java backends connect to each
  other exactly as the CLI does (`HELLO`/`ACK`/`MSG`, invites, group gossip).
- The React UI never speaks the peer protocol. It connects only to **its own
  local backend** over a second WebSocket (the "control" channel) and sends UI
  commands / receives UI events. There is **no REST endpoint**.

## What was added (and what was left untouched)

Untouched peer‑to‑peer code: `network/*`, `protocol/*`, `group/Group`, and the
CLI `ui/Ui`. The only change to `group/GroupManager` is two **read‑only**
accessors (`groupsSnapshot()`, `isMemberOf()`) used to render state — they don't
alter any behaviour.

New backend package `com.lseg.control`:

- `UiController` — holds the same `ConnectionManager` + `GroupManager` the CLI
  uses, translates JSON UI commands into the identical manager calls, and emits
  structured JSON events back to the UI.
- `ControlServer` — a local WebSocket server (separate from `PeerServer`) that
  the React UI connects to. Peers never touch this socket.
- `ControlMain` — an alternative entry point that starts the control bridge.
  The interactive CLI (`com.lseg.Main`) still works exactly as before.

New frontend pieces:

- `src/net/protocol.ts` — the command/event message shapes.
- `src/net/controlClient.ts` — a singleton WebSocket client that sends commands
  and dispatches Redux actions on incoming events (auto‑reconnects).
- The Redux store (`src/store/*`) now holds real peers/groups/messages driven by
  backend events instead of mock data.
- A name/port entry screen (`src/features/NameGate`) and real wiring in
  `ConnectSection`, `TopBar`, `SideBar`, `ChatArea`.

## Control protocol (UI ⇄ backend)

Commands (UI → backend), one JSON object per message:

| cmd | fields | CLI equivalent |
| --- | --- | --- |
| `init` | `name`, `listenPort?` | the startup name prompt + auto‑listen |
| `connect` | `host`, `port` | `connect <host> <port>` |
| `listen` | `port` | `listen <port>` |
| `close` | `id` | `close <id>` |
| `sendDirect` | `to`, `text` | `to_<name> <msg>` (here `to` is the connection id) |
| `sendGroup` | `group`, `text` | `@<group> <msg>` |
| `groupCreate` | `name` | `group create <name>` |
| `invite` | `peer`, `group` | `invite <peer> <group>` |
| `accept` / `reject` | `group` | `accept` / `reject <group>` |
| `leave` | `group` | `leave <group>` |

Events (backend → UI): `ready`, `peers`, `peerConnected`, `peerDisconnected`,
`message`, `groupMessage`, `groups`, `invite`, `log`, `error`. The `log` events
carry the exact strings the CLI would have printed, so nothing is lost.

## Running two apps that connect to each other

### 1. Start each backend as a control bridge

Run `com.lseg.control.ControlMain` instead of `com.lseg.Main`. The control port
comes from the first program argument, then the `CONTROL_PORT` env var, then
defaults to `8090`.

Backend for **App A** (control port 8090):

```
# In your IDE: run com.lseg.control.ControlMain  (no args → 8090)
# Or on the command line, using the same libraries the project already needs
# (java-websocket, jackson-databind/core/annotations, log4j-api/core):
java -cp "out:libs/*" com.lseg.control.ControlMain 8090
```

Backend for **App B** (control port 8091):

```
java -cp "out:libs/*" com.lseg.control.ControlMain 8091
```

> Note: the backend uses recent‑Java preview features, so compile/run it with the
> same JDK and settings you already use for `com.lseg.Main`. Adjust the
> classpath (`-cp`) to wherever your compiled classes and dependency jars live.
> Running from the IDE is the simplest path — just pick `ControlMain` and set the
> program argument to the port.

Each backend prints e.g. `Control bridge listening on ws://127.0.0.1:8090`.

### 2. Start each React UI pointed at its backend

In `app/front`:

```
npm install          # first time only
```

App A UI (talks to 8090 — the default, no env needed):

```
npm run dev
```

App B UI (talks to 8091) — set the control URL for that instance:

```
# bash / zsh
VITE_CONTROL_URL=ws://127.0.0.1:8091 npm run dev -- --port 5174

# PowerShell
$env:VITE_CONTROL_URL="ws://127.0.0.1:8091"; npm run dev -- --port 5174
```

(Or copy `.env.example` to `.env` in each checkout and set `VITE_CONTROL_URL`.)

### 3. Connect the two apps

1. Open both UIs in the browser. Each shows the name screen once its backend is
   online ("● backend online").
2. Enter a name in each (e.g. `alice` and `bob`) and click **start**. The top bar
   shows the peer listening port your backend chose, e.g. `listening on port
   54321`.
3. In App A, use the **connect** row: host `127.0.0.1`, port = App B's *peer*
   listening port (the number shown in App B's top bar, **not** 8091). Click
   **connect**.
4. Both apps now list each other under **peers**. Click a peer and chat — messages
   flow backend‑to‑backend over the real peer‑to‑peer link.

### 4. Groups

1. In either app, type a group name and click **create**.
2. Select the group, click **invite**, tick a connected peer, and **invite
   selected**.
3. The invited app shows the invite under **invites** with **accept** / **reject**.
   On accept, the backends wire up the group (including connecting to other
   advertised members) exactly as the CLI does, and `@group` messages are
   delivered to everyone.

## Notes / gotchas

- Two backends on the **same machine** need distinct control ports *and* will get
  distinct random peer ports automatically. On **different machines** you can
  leave both control ports at the default 8090.
- The control socket binds to `127.0.0.1` only — it is a local UI channel, not
  something other peers connect to.
- If a UI shows "backend offline", start (or restart) that app's `ControlMain`;
  the UI reconnects on its own.
- `to` in `sendDirect` is the backend **connection id** (e.g. `c1`), which the UI
  sends automatically when you have a peer selected — this avoids ambiguity when
  two peers share a name.
