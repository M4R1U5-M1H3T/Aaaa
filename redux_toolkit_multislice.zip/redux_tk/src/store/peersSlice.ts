import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import type { Peer, ChatMessage } from "../models";
import type { RootState } from "./store";

export type PeersState = Peer[];

const initialState: PeersState = [
  { id: "p1", name: "alice", online: true, messages: [] },
  { id: "p2", name: "bob", online: false, messages: [] },
];

const peersSlice = createSlice({
  name: "peers",
  initialState,
  reducers: {
    addPeer: (state, action: PayloadAction<Peer>) => {
      state.push(action.payload);
    },

    setPeerOnline: (state, action: PayloadAction<string>) => {
      const peer = state.find((p) => p.id === action.payload);
      if (peer) peer.online = true;
    },

    messageAddedToPeer: (
      state,
      action: PayloadAction<{ peerId: string; message: ChatMessage }>
    ) => {
      const peer = state.find((p) => p.id === action.payload.peerId);
      peer?.messages.push(action.payload.message);
    },
  },
});

export const { addPeer, setPeerOnline, messageAddedToPeer } = peersSlice.actions;
export const peersReducer = peersSlice.reducer;

// Selectors
export const selectPeers = (state: RootState) => state.peers;

export const selectPeerById = (state: RootState, peerId: string) =>
  state.peers.find((p) => p.id === peerId);
