import { createSlice } from "@reduxjs/toolkit";
import type { PayloadAction } from "@reduxjs/toolkit";
import type { Group, ChatMessage } from "../models";
import type { RootState } from "./store";

export type GroupsState = Group[];

const initialState: GroupsState = [
  { id: "g1", name: "general", members: ["alice"], messages: [] },
];

const groupsSlice = createSlice({
  name: "groups",
  initialState,
  reducers: {
    addGroup: (state, action: PayloadAction<Group>) => {
      state.push(action.payload);
    },

    membersInvited: (
      state,
      action: PayloadAction<{ groupId: string; names: string[] }>
    ) => {
      const group = state.find((g) => g.id === action.payload.groupId);
      if (group) group.members.push(...action.payload.names);
    },

    messageAddedToGroup: (
      state,
      action: PayloadAction<{ groupId: string; message: ChatMessage }>
    ) => {
      const group = state.find((g) => g.id === action.payload.groupId);
      group?.messages.push(action.payload.message);
    },
  },
});

export const { addGroup, membersInvited, messageAddedToGroup } = groupsSlice.actions;
export const groupsReducer = groupsSlice.reducer;

// Selectors
export const selectGroups = (state: RootState) => state.groups;

export const selectGroupById = (state: RootState, groupId: string) =>
  state.groups.find((g) => g.id === groupId);
