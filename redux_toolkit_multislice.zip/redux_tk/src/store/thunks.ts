import type { AppDispatch, RootState } from "./store";
import type { Group } from "../models";
import { addGroup, membersInvited, messageAddedToGroup } from "./groupsSlice";
import { messageAddedToPeer } from "./peersSlice";
import { openGroup, closeInvite } from "./uiSlice";

// These actions each need to read/update more than one slice
// (which slice a message goes to, where a new group's id comes from, etc.),
// so they live here as thunks instead of inside a single slice.

export const sendMessage =
  (text: string) => (dispatch: AppDispatch, getState: () => RootState) => {
    const trimmed = text.trim();
    if (trimmed === "") return;
    const message = { author: "You", text: trimmed, fromMe: true };

    const state = getState();
    if (state.ui.selectedPeerId) {
      dispatch(messageAddedToPeer({ peerId: state.ui.selectedPeerId, message }));
    } else if (state.ui.selectedGroupId) {
      dispatch(messageAddedToGroup({ groupId: state.ui.selectedGroupId, message }));
    }
  };

export const createGroup =
  (name: string) => (dispatch: AppDispatch, getState: () => RootState) => {
    const trimmed = name.trim();
    if (trimmed === "") return;

    const state = getState();
    const group: Group = {
      id: `g${state.groups.length + 1}`,
      name: trimmed,
      members: [],
      messages: [],
    };

    dispatch(addGroup(group));
    dispatch(openGroup(group.id));
  };

export const invite =
  (groupId: string, names: string[]) => (dispatch: AppDispatch) => {
    dispatch(membersInvited({ groupId, names }));
    dispatch(closeInvite());
  };
