import { configureStore, combineReducers } from "@reduxjs/toolkit";
import { peersReducer } from "./peersSlice";
import { groupsReducer } from "./groupsSlice";
import { uiReducer } from "./uiSlice";

const rootReducer = combineReducers({
  peers: peersReducer,
  groups: groupsReducer,
  ui: uiReducer,
});

export const store = configureStore({
  reducer: rootReducer,
});

export type RootState = ReturnType<typeof rootReducer>;
export type AppDispatch = typeof store.dispatch;
