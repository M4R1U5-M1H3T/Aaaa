import { useState } from "react";
import { useAppDispatch, useAppSelector, addGroup, openGroup, selectGroups } from "../../store";

export const useGroupHook = () => {
  const dispatch = useAppDispatch();
  const groups = useAppSelector(selectGroups);
  const [name, setName] = useState("");

  const handleCreate = () => {
    const trimmed = name.trim();
    if (trimmed !== "") {
      const group = {
        id: `g${groups.length + 1}`,
        name: trimmed,
        members: [],
        messages: [],
      };
      dispatch(addGroup(group));
      dispatch(openGroup(group.id));
    }
    setName("");
  };

  return { name, setName, handleCreate };
};
