import { useState } from "react";
import {
  useAppDispatch,
  useAppSelector,
  messageAddedToPeer,
  messageAddedToGroup,
  selectSelectedPeerId,
  selectSelectedGroupId,
} from "../../store";

export const useMessageHook = () => {
  const dispatch = useAppDispatch();
  const selectedPeerId = useAppSelector(selectSelectedPeerId);
  const selectedGroupId = useAppSelector(selectSelectedGroupId);
  const [text, setText] = useState("");

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const trimmed = text.trim();
    if (trimmed !== "") {
      const message = { author: "You", text: trimmed, fromMe: true };
      if (selectedPeerId) {
        dispatch(messageAddedToPeer({ peerId: selectedPeerId, message }));
      } else if (selectedGroupId) {
        dispatch(messageAddedToGroup({ groupId: selectedGroupId, message }));
      }
    }
    setText("");
  };

  return { text, setText, handleSubmit };
};
