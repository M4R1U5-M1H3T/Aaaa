import { useState } from "react";
import {
  useAppDispatch,
  useAppSelector,
  membersInvited,
  closeInvite,
  selectActiveGroup,
} from "../../store";

export const useInviteHook = () => {
  const dispatch = useAppDispatch();
  const activeGroup = useAppSelector(selectActiveGroup);
  const [selected, setSelected] = useState<string[]>([]);

  const toggle = (name: string) => {
    setSelected((current) =>
      current.includes(name) ? current.filter((n) => n !== name) : [...current, name]
    );
  };

  const handleSubmit = () => {
    if (activeGroup) {
      dispatch(membersInvited({ groupId: activeGroup.id, names: selected }));
      dispatch(closeInvite());
    }
    setSelected([]);
  };

  return { selected, toggle, handleSubmit };
};
